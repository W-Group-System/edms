<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('login_css/css/plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper wrapper-content">
        <div class="row">
            <div class="col-lg-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Approved Memorandum</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins"><?php echo e($memos->filter(fn($doc) => $doc->final_status == 'Approved' || is_null($doc->final_status))->count()); ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-lg-3"> 
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Declined Memorandum</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins"><?php echo e($memos->filter(fn($doc) => $doc->final_status == 'Declined' && $doc->uploaded_by == auth()->id())->count()); ?></h1>
                    </div>
                    
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Memorandum
                            
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#new">
                                <i class="fa fa-plus"></i>
                                &nbsp;
                                Upload
                            </button>
                            
                        </h5>

                         
                    
                    <div class="ibox-tools">
                        <form method="GET" action="" id="filterForm" style="display: inline-block; width: 150px;">
                            <select name="status_filter" id="status_filter" class="form-control input-sm" onchange="this.form.submit()">
                                <option value="">All Status</option>
                                <option value="Approved" <?php echo e(request('status_filter') == 'Approved' ? 'selected' : ''); ?>>Approved</option>
                                <option value="Declined" <?php echo e(request('status_filter') == 'Declined' ? 'selected' : ''); ?>>Declined</option>
                            </select>
                        </form>
                    </div>
                    
                    </div>
                    
                    <div class="ibox-content">
                        <div class="table table-responsive">
                            <table class="table table-striped table-bordered table-hover tables" >
                                <thead>
                                    <tr>
                                        <th>Action</th>
                                        <th>Public</th>
                                        <th>Department</th>
                                        <th>Memo Number</th>
                                        <th>Title</th>
                                        <th>Released Date</th>
                                        <th>Uploaded By</th>
                                        <th>Align Policy</th>
                                        <th>Attachment</th>
                                        <th>Remarks</th>
                                        <th>Visibility</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $memos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        
                                        <?php if(request('status_filter')): ?>
                                            <?php
                                                $filter = request('status_filter');
                                                $isApproved = ($memo->final_status == 'Approved' || is_null($memo->final_status));
                                                
                                                if ($filter == 'Approved' && !$isApproved) {
                                                    continue;
                                                }
                                                if ($filter == 'Declined' && $memo->final_status != 'Declined') {
                                                    continue;
                                                }
                                            ?>
                                        <?php endif; ?>

                                        <tr>
                                            <td>
                                                <?php if($memo->final_status != 'Declined'): ?>
                                                    
                                                    
                                                    <?php if($memo->department_id == auth()->user()->department_id): ?>
                                                    <button type="button" class="btn btn-sm btn-warning" title="Edit" data-toggle="modal" data-target="#edit<?php echo e($memo->id); ?>">
                                                        <i class="fa fa-pencil-square-o"></i>
                                                    </button>
                                                    <?php endif; ?>
                                                    
                                                    <?php if(auth()->user()->role == 'Document Control Officer'): ?>
                                                    <button type="button" class="btn btn-sm btn-danger deleteMemo" id="<?php echo e($memo->id); ?>">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="text-muted" style="font-size: 11px; font-style: italic;">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if(auth()->user()->role == 'Document Control Officer' || auth()->user()->role == 'Administrator'): ?>
                                                    <form method="POST" action="<?php echo e(url('update_status/'.$memo->id)); ?>" onsubmit="show()" id="updateStatusForm<?php echo e($memo->id); ?>">
                                                        <?php echo csrf_field(); ?> 

                                                        <input type="checkbox" name="status" class="form-check" onchange="updateStatus(<?php echo e($memo->id); ?>)" value="Public" 
                                                            <?php if($memo->status == 'Public'): ?> checked <?php endif; ?>
                                                            <?php if($memo->final_status == 'Declined'): ?> disabled <?php endif; ?>>
                                                    </form>
                                                <?php endif; ?>
                                            </td>

                                            <td><?php echo e($memo->department->name ?? 'N/A'); ?></td>
                                            <td><?php echo e($memo->memo_number); ?></td>
                                            <td><?php echo e($memo->title); ?></td>
                                            <td><?php echo e(date('M d Y', strtotime($memo->released_date))); ?></td>
                                            <td><?php echo e($memo->user->name ?? 'N/A'); ?></td>
                                            <td>
                                                <?php $__currentLoopData = $memo->memorandum_document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memo_docs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(url('view-document/'.$memo_docs->document->id)); ?>"><?php echo e($memo_docs->document->control_code); ?></a> <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url($memo->file_memo)); ?>" target="_blank">
                                                    <i class="fa fa-file"></i>
                                                </a>
                                            </td>
                                            <td>
                                                <?php if($memo->final_status == 'Declined'): ?>
                                                    <span class="text-danger"><?php echo e($memo->remarks ?? 'N/A'); ?></span>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($memo->status == 'Private'): ?>
                                                    <span class="label label-danger">Private</span>
                                                <?php else: ?>
                                                    <span class="label label-success">Public</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($memo->final_status == 'Declined'): ?>
                                                    <span class="label label-warning">
                                                        Declined
                                                    </span>
                                                <?php else: ?>
                                                    <span class="label label-primary">
                                                        <?php echo e($memo->final_status ?? 'Approved'); ?>

                                                    </span>
                                                <?php endif; ?>
                                            </td> 
                                           
                                        </tr>

                                        <?php echo $__env->make('edit_memorandum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <?php echo $__env->make('approved_memorandum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('new_memorandum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/sweetalert/sweetalert.min.js')); ?>"></script>
<script>
    function updateStatus(id)
    {
        $('#updateStatusForm'+id).submit()
        
    }

    $(document).ready(function(){
        $(".cat").chosen({width:"100%"})

        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

        $("#type").on('change', function() {
            if($(this).val() == 'Align Policy')
            {
                $("#policySelectOption").removeAttr('hidden')
                $("[name='document[]']").prop('required', true)
            }
            else
            {
                $("#policySelectOption").prop('hidden', true)
                $("[name='document[]']").removeAttr('required')
            }
        })

        $('.deleteMemo').click(function () {
            var id = this.id;
            
            swal({
                title: "Are you sure?",
                text: "This memo will be deleted!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false
            }, function (){
                $.ajax({
                    dataType: 'json',
                    type:'POST',
                    url:  '<?php echo e(url("delete_memo")); ?>',
                    data:{id:id},
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                }).done(function(data){
                    console.log(data);
                    swal("Deleted!", "Memo is now deleted.", "success");
                    location.reload();
                }).fail(function(data)
                {
                    
                    swal("Deleted!", "Memo is now deleted.", "success");
                location.reload();
                });
            });
        });
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>