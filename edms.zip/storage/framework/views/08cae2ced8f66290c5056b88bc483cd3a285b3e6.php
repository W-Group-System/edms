<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
        <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Pending</h5>
                </div>
                <div class="ibox-content">
                    <form method="GET">
                        <h1 class="no-margins">
                            <input type="hidden" name="status" value="NotDelayed">
                            <input type="submit" class="text-success" value="<?php echo e($notDelayedCount); ?>" style="background: none; border: none;">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Declined</h5>
                </div>
                <div class="ibox-content">
                    <form method="get" action="">
                        <h1 class="no-margins">
                            <input type="hidden" name="status" value="Declined">
                            <input type="submit" class="text-success" value="<?php echo e($declinedCount); ?>" style="background: none; border: none;">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Approved</h5>
                </div>
                <div class="ibox-content">
                    <form action="" method="get">
                        <input type="hidden" name="status" value="Approved">
                        <h1 class="no-margins">
                            <input type="submit" class="text-success" value="<?php echo e($approvedCount); ?>"  style="background: none; border: none;">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Delayed</h5>
                </div>
                <div class="ibox-content">
                    
                    <form action="" method="get">
                        <input type="hidden" name="status" value="Delayed">
                        <h1 class="no-margins">
                            <input type="submit" class="text-success" value="<?php echo e($delayedCount); ?>"  style="background: none; border: none;">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Pre-Assessment Returned</h5>
                </div>
                <div class="ibox-content">
                    <form action="" method="get">
                        <input type="hidden" name="status" value="Pre-Assessment Returned">
                        <h1 class="no-margins">
                            <input type="submit" class="text-success" value="<?php echo e($returnedCount); ?>"  style="background: none; border: none;">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class='row'>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Change Requests
                        
                        <?php if(auth()->user()->role == "User"): ?>
                        <button class="btn btn-success "  data-target="#newRequest" data-toggle="modal" type="button"><i class="fa fa-plus"></i>&nbsp;New </button>
                        <?php endif; ?>
                    </h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables">
                            <thead>
                                <tr>
                                    
                                    <th>Actions</th>
                                    <th>Reference No.</th>
                                    <th>Request Type</th>
                                    <th>Date Requested</th>
                                    <th>Code</th>
                                    <th>Title</th>
                                    <th>Revision</th>
                                    <th>Type</th>
                                    <th>Requested By</th>
                                    <th>Target Date</th>
                                    <th>Approved Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                        <tbody>
                            <?php
                                $delayed = 0;
                            ?>
                            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if(($request->type_of_document == "FORM") ||($request->type_of_document == "TEMPLATE")): ?>
                                <?php
                                    $date_push = date('Y-m-d', strtotime('2024-08-22'));
                                    if ($date_push > date('Y-m-d', strtotime($request->created_at)))
                                    {
                                        $target = date('Y-m-d', strtotime("+7 days", strtotime($request->created_at))); 
                                    }
                                    else
                                    {
                                        // $departmentHeadApproval = date('Y-m-d', strtotime($request->department_head_approved));
                                        // if ($departmentHeadApproval !=  null) {
                                        //     $target = date('Y-m-d', strtotime("+7 days", strtotime($departmentHeadApproval)));
                                        // }
                                        // else
                                        // {
                                        //     $target = date('Y-m-d');
                                        // }
                                        if ($request->department_head_approved != null)
                                        {
                                            $target = date('Y-m-d', strtotime("+7 days", strtotime($request->department_head_approved)));
                                        }
                                        else
                                        {
                                            if ($request->preAssessment != null)
                                            {
                                                if ($request->preAssessment->status == 'Approved' && $request->dco_approved != null)
                                                {
                                                    $target = date('Y-m-d', strtotime("+7 days", strtotime($request->created_at)));
                                                    // $target = "";
                                                }
                                                else
                                                {
                                                    $target = date('Y-m-d', strtotime("+10 days", strtotime($request->preAssessment->created_at)));
                                                }
                                            }
                                            else
                                            {
                                                // For old data that does not have pre assessment
                                                $target = date('Y-m-d', strtotime("+7 days", strtotime($request->created_at))); 
                                            }
                                        }
                                    }
                                ?>
                            <?php elseif($request->type_of_document == "ANNEX"): ?>
                                <?php
                                    $date_push = date('Y-m-d', strtotime('2024-08-22'));
                                    if ($date_push > date('Y-m-d', strtotime($request->created_at)))
                                    {
                                        $target = date('Y-m-d', strtotime("+20 days", strtotime($request->created_at))); 
                                    }
                                    else
                                    {
                                        if ($request->department_head_approved != null)
                                        {
                                            $target = date('Y-m-d', strtotime("+20 days", strtotime($request->department_head_approved)));
                                        }
                                        else
                                        {
                                            if ($request->preAssessment != null)
                                            {
                                                if ($request->preAssessment->status == 'Approved' && $request->dco_approved != null)
                                                {
                                                    $target = date('Y-m-d', strtotime("+20 days", strtotime($request->created_at)));
                                                }
                                                else
                                                {
                                                    $target = date('Y-m-d', strtotime("+20 days", strtotime($request->preAssessment->created_at)));
                                                }
                                            }
                                            else
                                            {
                                                // For old data that does not have pre assessment
                                                $target = date('Y-m-d', strtotime("+20 days", strtotime($request->created_at))); 
                                            }
                                        }
                                    }
                                ?>
                            <?php else: ?>
                                <?php
                                    $date_push = '2024-08-22';
                                    if ($date_push > date('Y-m-d', strtotime($request->created_at)))
                                    {
                                        $target = date('Y-m-d', strtotime("+1 month", strtotime($request->created_at))); 
                                    }
                                    else
                                    {
                                        // $departmentHeadApproval = date('Y-m-d', strtotime($request->department_head_approved));
                                        // if ($departmentHeadApproval != null) {
                                        //     $target = date('Y-m-d', strtotime("+1 month", strtotime($departmentHeadApproval)));
                                        // }
                                        // else
                                        // {
                                        //     $target = date('Y-m-d');
                                        // }
                                        if ($request->department_head_approved != null)
                                        {
                                            $target = date('Y-m-d', strtotime("+30 day", strtotime($request->department_head_approved))); 
                                        }
                                        else
                                        {
                                            if ($request->preAssessment != null)
                                            {
                                                if ($request->preAssessment->status == 'Approved' && $request->dco_approved != null)
                                                {
                                                    $target = date('Y-m-d', strtotime("+20 days", strtotime($request->dco_approved)));
                                                }
                                                else
                                                {
                                                    $target = date('Y-m-d', strtotime("+10 days", strtotime($request->preAssessment->created_at)));
                                                }
                                            }
                                            else
                                            {
                                                // For old data that does not have pre assessment
                                                $target = date('Y-m-d', strtotime("+1 month", strtotime($request->created_at))); 
                                            }
                                        }
                                    } 
                                ?>
                            <?php endif; ?>
                                    <tr>
                                        
                                        <td><a href="#"  data-target="#view_request<?php echo e($request->id); ?>" data-toggle="modal" class='btn btn-sm btn-info'><i class="fa fa-eye"></i></a>
                                            <?php if((auth()->user()->role == "Document Control Officer") || (auth()->user()->role == "Administrator")): ?>
                                                <?php if($request->status == "Pending"): ?>
                                                    <?php if($request->request_type == "Revision"): ?>
                                                        <a href="#"  data-target="#edit_request<?php echo e($request->id); ?>" data-toggle="modal" class='btn btn-sm btn-warning'><i class="fa fa-edit"></i></a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php elseif($request->status == "Pre-Assessment Returned"): ?>
                                                <a href="#"  data-target="#updateRequest<?php echo e($request->pre_assessment_id); ?>" data-toggle="modal" class='btn btn-sm btn-warning'><i class="fa fa-edit"></i></a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(optional($request->preAssessment)->status != "Pending"): ?>
                                            DICR-<?php echo e(str_pad($request->id, 5, '0', STR_PAD_LEFT)); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($request->request_type); ?></td>
                                        <td><?php echo e(date('Y-m-d',strtotime($request->created_at))); ?></td>
                                     
                                            <?php if($request->document_id != null): ?>
                                            <td>
                                                <?php echo e($request->control_code); ?>

                                            </td>   
                                            <td>
                                                <?php echo e($request->title); ?>

                                            </td>   
                                            <td>
                                                <?php echo e($request->revision); ?>

                                            </td>   
                                           
                                            <?php else: ?>
                                            <td></td>
                                            <td><?php echo e($request->title); ?></td>
                                            <td></td>
                                            <?php endif; ?>
                                            <td>
                                                <?php echo e($request->type_of_document); ?>

                                            </td>   
                                        <td><?php echo e($request->user->name); ?></td>
                                        <td>
                                            <?php if($target != null): ?>
                                                <?php echo e(date('Y-m-d', strtotime($target))); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($request->status == 'Approved'): ?>
                                                <?php echo e(date('Y-m-d', strtotime($request->updated_at))); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td> 
                                            <?php if(optional($request->preAssessment)->status == "Pending"): ?>
                                                <span style="background-color: #b9ff66; font-weight: bold;" class="label"> Pre-Assessment
                                                
                                            <?php else: ?>
                                                <?php if($request->status == "Pending"): ?>
                                                    <?php if($target != null): ?>
                                                        <?php if($target < date('Y-m-d')): ?>
                                                        <?php
                                                            $delayed++;
                                                        ?>
                                                        <span class='label label-danger'>
                                                            Delayed - 
                                                        <?php else: ?>
                                                        <span class='label label-success'>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <span class='label label-success'>
                                                    <?php endif; ?>
                                                <?php elseif($request->status ==  "Approved"): ?>
                                                    <span class='label label-info'>    
                                                <?php elseif($request->status ==  "Declined"): ?>
                                                        <span class='label label-warning'>
                                                <?php elseif($request->status ==  "Pre-Assessment Returned"): ?>
                                                        <span class='label label-warning'>
                                                <?php else: ?><span class='label label-success'>
                                                <?php endif; ?>

                                                <?php echo e($request->status); ?> 
                                            <?php endif; ?>

                                            </span>  
                                        </td>
                                    </tr>
                                    <?php echo $__env->make('view_change_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <?php echo $__env->make('edit_change_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <?php echo $__env->make('update_change_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>
<?php echo $__env->make('new_change_request_image', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('new_change_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<?php if($status == null): ?>
<script type="text/javascript">
    $(window).on('load', function() {
        $('#myModal').modal('show');
    });
</script>
<?php endif; ?>
<script>
    // var delayed = <?php echo json_encode($delayed); ?>;
    // document.getElementById('delayed').innerText = delayed;
    // document.getElementById('delayed').value = delayed;
    $(document).ready(function(){
        

        $('.cat').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>