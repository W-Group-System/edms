<div class="modal" id="edit<?php echo e($memo->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit memorandum</h5>
            </div>
            <form method="POST" action="<?php echo e(url('update_memorandum/'.$memo->id)); ?>" enctype="multipart/form-data" onsubmit="show()">
                <?php echo csrf_field(); ?> 

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            Memo Number :
                            <input type="text" name="memo_number" class="form-control input-sm" value="<?php echo e($memo->memo_number); ?>" readonly>
                        </div>
                        <div class="col-md-12">
                            Title :
                            <input type="text" name="title" class="form-control input-sm" value="<?php echo e($memo->title); ?>" required>
                        </div>
                        <div class="col-md-12">
                            Released Date :
                            <input type="date" name="released_date" class="form-control input-sm" min="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e($memo->released_date); ?>" required>
                        </div>
                        <div class="col-md-12">
                            Align Policy :
                            <select data-placeholder="Choose policy" name="document" class="form-control cat" required>
                                <option value=""></option>
                                <?php if(auth()->user()->role == 'User'): ?>
                                    <?php $__currentLoopData = $documents->where('department_id', auth()->user()->department_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($document->id); ?>"><?php echo e($document->control_code .' - '.$document->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($document->id); ?>"><?php echo e($document->control_code .' - '.$document->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col-md-12">
                            Upload Memo :
                            <input type="file" name="memo_file" class="form-control" >
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>