<?php $__env->startSection('content'); ?>

    <h1>You are currently not connected to any networks.</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>