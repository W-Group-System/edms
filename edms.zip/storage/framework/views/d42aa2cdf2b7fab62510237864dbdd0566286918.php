
<div class="modal" id="view_request_copy<?php echo e($request->id); ?>" tabindex="-1" role="dialog"  >
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class='col-md-10'>
                    <h5 class="modal-title" id="exampleModalLabel">View Copy Request (<?php echo e($request->status); ?>)</h5>
                </div>
                <div class='col-md-2'>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            <form method='post' action='<?php echo e(url('copy-request-action/'.$copy_approval->id)); ?>' onsubmit='show();' class="form-horizontal"  enctype="multipart/form-data" >
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($copy_approval->copy_request->document_id); ?>">
                <input type="hidden" name="user_id" value="<?php echo e($request->user->id); ?>">
                <div class="modal-body">
                    <div class='row '>
                        <div class='col-md-6'>
                            Reference Number : <b>CR-<?php echo e(str_pad($request->id, 5, '0', STR_PAD_LEFT)); ?></b>
                        </div>
                        <div class='col-md-6'>
                            Type of Document : <?php echo e($request->type_of_document); ?>

                        </div>
                        <div class='col-md-6'>
                            Date Needed : <?php echo e(date('M d Y',strtotime($request->date_needed))); ?>

                        </div>
                        <div class='col-md-6'>
                           Copy Needed : <?php echo e($request->copy_count); ?>

                        </div>
                    </div>
                    <hr>
                    <div class='row '>
                        <div class='col-md-6'>
                            Control Code : <?php echo e($request->control_code); ?> Rev. <?php echo e($request->revision); ?>

                        </div>
                        <div class='col-md-6'>
                            Title : <?php echo e($request->title); ?>

                        </div>
                    </div>
                    <div class='row '>
                        <div class='col-md-6'>
                            Requested By : <?php echo e($request->user->name); ?> 
                        </div>
                        <div class='col-md-6'>
                            Date Requested : <?php echo e(date('M d, Y',strtotime($request->created_at))); ?>

                        </div>
                    </div>
                    <div class='row '>
                        <div class='col-md-12'>
                            Purpose : <?php echo e($request->purpose); ?> 
                        </div>
                    </div>
                    <?php
                        $document =$request->document;
                    ?>
                    <?php if($request->level > 1): ?>
                    <hr>
                     <div class="row">
                            <div class="col-lg-12">
                               Document Request : 
                                        <?php $__currentLoopData = $document->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($attachment->attachment != null): ?>
                                               <?php if($attachment->type == "pdf_copy"): ?>
                                                    <?php if(($document->category == "FORM") || ($document->category == "TEMPLATE")): ?><a href='<?php echo e(url($attachment->attachment)); ?>' target="_blank" ><i class="fa fa-file-pdf-o"></i> PDF Copy</a>
                                                    <?php else: ?><a href='<?php echo e(url('view-pdf/'.$attachment->id)); ?>' target="_blank" ><i class="fa fa-file-pdf-o"></i> PDF Copy</a>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                             <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                </dl>
                            </div>
                    </div>
                    <?php endif; ?>
                    <hr>
                        <div class='row text-center'>
                            <div class='col-md-3 border  border-primary border-top-bottom border-left-right'>
                            Approver
                            </div>
                            <div class='col-md-3 border  border-primary border-top-bottom border-left-right'>
                            Status
                            </div>
                            <div class='col-md-2 border  border-primary border-top-bottom border-left-right'>
                            Start Date
                            </div>
                            <div class='col-md-2 border  border-primary border-top-bottom border-left-right'>
                            Action Date
                            </div>
                            <div class='col-md-2 border  border-primary border-top-bottom border-left-right'>
                            Remarks
                            </div>
                        </div>
                    <?php $__currentLoopData = $request->approvers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class='row text-left'>
                            <div class='col-md-3 border border-primary border-top-bottom border-left-right'>
                            <?php echo e($approver->user->name); ?> &nbsp;
                            </div>
                            <div class='col-md-3 border border-primary border-top-bottom border-left-right'>
                                <?php echo e($approver->status); ?> &nbsp;
                            </div>
                            <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                <?php if($approver->start_date != null): ?><?php echo e(date('M d, Y',strtotime($approver->start_date))); ?><?php endif; ?> &nbsp;
                            </div>
                            <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                <?php if($approver->level < $request->level): ?><?php echo e(date('M d, Y',strtotime($approver->updated_at))); ?><?php endif; ?> &nbsp;
                            </div>
                            <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                <?php echo nl2br(e($approver->remarks)); ?> &nbsp;
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <div class='row'>
                        <div class='col-md-4'>
                            Action :
                            <select name='action' class='form-control-sm form-control cat' required>
                                <option value=""></option>
                                <option value="Approved" >Approve</option>
                                <option value="Declined" >Decline</option>
                            </select>
                        </div>
                        <div class='col-md-8'>
                            Remarks :
                            <textarea name='remarks' class='form-control-sm form-control' required></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type='submit'  class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
