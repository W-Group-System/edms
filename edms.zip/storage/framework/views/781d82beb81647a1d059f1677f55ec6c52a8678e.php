<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <div class="row">
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>For Approval</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e($copy_for_approvals->where('status', 'Pending')->count() + $change_for_approvals->where('status', 'Pending')->count() + $prr->where('status', 'Pending')->count()); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Approved</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($copy_for_approvals->where('status','Approved'))+count($change_for_approvals->where('status','Approved')) + $prr->where('status', 'Completed')->count()); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Declined</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($copy_for_approvals->where('status','Declined'))+count($change_for_approvals->where('status','Declined')) + $prr->where('status', 'Returned')->count()); ?></h1>
                </div>
            </div>
        </div>
    </div>
    <div class='row'>
        <div class="col-lg-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Copy Requests</h5>
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                            <thead>
                                <tr>
                                    
                                    <th>Actions</th>
                                    <th>Reference Number</th>
                                    <th>Date Requested</th>
                                    <th>Document</th>
                                    <th>Requested By</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $copy_for_approvals->where('status','Pending'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $copy_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $request = $copy_approval->copy_request;
                                ?>
                                <tr>
                                    
                                    <td><a href="#"  data-target="#view_request_copy<?php echo e($copy_approval->copy_request->id); ?>" data-toggle="modal" class='btn btn-sm btn-info'><i class="fa fa-eye"></i></a></td>
                                    <td>CR-<?php echo e(str_pad($request->id, 5, '0', STR_PAD_LEFT)); ?></td>
                                    <td><?php echo e(date('M d Y',strtotime($copy_approval->copy_request->created_at))); ?></td>
                                    <td><small>
                                        <?php echo e($copy_approval->copy_request->control_code); ?> Rev. <?php echo e($copy_approval->copy_request->revision); ?><br>
                                        <?php echo e($copy_approval->copy_request->title); ?> <br>
                                        <?php echo e($copy_approval->copy_request->type_of_document); ?>

                                    </small></td>
                                    <td><?php echo e($copy_approval->copy_request->user->name); ?></td>
                                    
                                </tr>
                               
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Change Requests</h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                        <thead>
                        <tr>
                            <th>Actions</th>
                            <th>Reference Number</th>
                            <th>Date Requested</th>
                            <th>Document</th>
                            <th>Requested By</th>
                            <th>Request Type</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $change_for_approvals->where('status', 'Pending'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $change_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $request = $change_approval->change_request;
                            ?>
                            <tr>
                                
                                <td>
                                    <a href="#"  data-target="#view_request_change<?php echo e($request->id); ?>" data-toggle="modal" class='btn btn-sm btn-info'><i class="fa fa-eye"></i></a>
                                    <?php if(auth()->user()->role == "Document Control Officer"): ?>
                                    <a href="#"  data-target="#edit_title<?php echo e($request->id); ?>" data-toggle="modal" class='btn btn-sm btn-warning'><i class="fa fa-edit"></i></a>
                                    <?php endif; ?>
                                </td>
                                <td>DICR-<?php echo e(str_pad($request->id, 5, '0', STR_PAD_LEFT)); ?></td>
                                <td><?php echo e(date('M d Y',strtotime($request->created_at))); ?></td>
                                <td><small>
                                    <?php echo e($request->control_code); ?> Rev. <?php echo e($request->revision); ?><br>
                                    <?php echo e($request->title); ?> <br>
                                    <?php echo e($request->type_of_document); ?>

                                </small></td>
                                <td><?php echo e($request->user->name); ?></td>
                                <td><?php echo e($request->request_type); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <?php
            $visiblePrr = $prr->filter(function ($request) {
                return in_array($request->status, ['Pending', 'Returned'])
                    || ($request->status === 'Completed' && $request->user_id == auth()->id());
            });
        ?>
        <div class="col-lg-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5 class="title">Process Review Request</h5>
                </div>
                <div class="ibox-content">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables">
                            <thead>
                                <tr>
                                    <th>Actions</th>
                                    <th>Reference Number</th>
                                    <th>Date Requested</th>
                                    <th>Document</th>
                                    <th>Request Type</th>
                                    <th>Requested by</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php $__currentLoopData = $visiblePrr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <button type="button btn-sm" data-target="#viewRequest<?php echo e($request->id); ?>" data-toggle="modal" class="btn btn-sm btn-info">
                                            <i class="fa fa-eye"></i>
                                        </button>
                                        <?php if(auth()->user()->role === 'Document Control Officer' && $request->status === 'Pending'): ?>
                                            <a href="#" data-target="#acceptPRR<?php echo e($request->id); ?>" data-toggle="modal" class="btn btn-sm btn-warning">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($request->reference_num ?? 'N/A'); ?></td>
                                    <td><?php echo e($request->created_at ? $request->created_at->format('M d, Y') : 'N/A'); ?></td>
                                    <td>
                                        <?php echo e($request->control_code ?? 'N/A'); ?><br>
                                        <?php echo e($request->document_title ?? 'N/A'); ?><br>
                                        <?php echo e($request->type_of_document ?? 'N/A'); ?>

                                    </td>
                                    <td><?php echo e($request->type_of_request); ?></td>
                                    <td><?php echo e(optional($request->user)->name ?? 'N/A'); ?></td>
                                    <td data-search="<?php echo e($request->status); ?>">
                                        <?php if($request->status == "Pending"): ?>
                                            <span class="label label-success">Pending</span>
                                        <?php elseif($request->status == "Accepted"): ?>
                                            <span class="label label-info">Accepted</span>
                                        <?php elseif($request->status == "Draft"): ?>
                                            <span class="label label-default">Draft</span>
                                        <?php elseif($request->status == "Completed"): ?>
                                            <span class="label label-primary">Completed</span>
                                        <?php elseif($request->status == "Returned"): ?>
                                            <span class="label label-danger">Returned</span>
                                        <?php elseif($request->status == "Declined"): ?>
                                            <span class="label label-danger">Declined</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $visiblePrr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('process-review.view-details', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php if(auth()->user()->role === 'Document Control Officer' && $request->status === 'Pending'): ?>
        <?php echo $__env->make('process-review.accept-prr', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $change_for_approvals->where('status','Pending'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $change_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$request = $change_approval->change_request;
?>
<?php echo $__env->make('view_approval_change', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('edit_title', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $copy_for_approvals->where('status','Pending'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $copy_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$request = $copy_approval->copy_request;
?>
<?php echo $__env->make('view_approval_copy', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script>
    function remove_required(id,value)
    {
        if(value=="Declined")
        {
            $('#soft_copy_'+id).prop('required',false);
            $('#pdf_copy_'+id).prop('required',false);

            $('.returnOptions'+id).css('display', 'none');
            $("#returned_to"+id).prop('required', false);
        }
        else if(value=="Returned")
        {
            $('#soft_copy_'+id).prop('required',false);
            $('#pdf_copy_'+id).prop('required',false);
            
            $('.returnOptions'+id).css('display', 'block');
            $("#returned_to"+id).prop('required', true);
        }
        else
        {
            $('#soft_copy_'+id).prop('required',true);
            $('#pdf_copy_'+id).prop('required',true);

            $('.returnOptions'+id).css('display', 'none');
            $("#returned_to"+id).prop('required', false);
        }
        
    }
    $(document).ready(function(){
        

        $('.cat').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            sorting: false,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>