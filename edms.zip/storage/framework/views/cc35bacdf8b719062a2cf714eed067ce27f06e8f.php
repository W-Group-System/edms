<div class="modal" id="viewRequest<?php echo e($request->id); ?>">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="col-md-10">
                    <h5 class="modal-title">
                        Quality Process Review Request (PRR)
                    </h5>
                </div>
                <div class="col-md-2">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        Reference Number : <?php echo e($request->reference_num ?? 'N/A'); ?>

                    </div>
                    <div class="col-md-6">
                        Type of Document : <?php echo e($request->type_of_document ?? 'N/A'); ?>

                    </div>
                    <div class="col-md-6">
                        Draft Link:
                        <?php if(!empty($request->link_draft)): ?>
                            <a href="<?php echo e(url($request->link_draft)); ?>" target="_blank">Draft Link</a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        Supporting Documents:
                        <?php if(!empty($request->supporting_documents)): ?>
                            <a href="<?php echo e(url($request->supporting_documents)); ?>" target="_blank">Link</a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </div>
                </div>
                
                <hr>
                <div class="row">
                    <?php if($request->type_of_request != "New"): ?>
                        <div class="col-md-6">
                            Control Code : <?php echo e($request->control_code ?? 'N/A'); ?>

                        </div>
                    <?php endif; ?>

                    <div class="col-md-6">
                        Title : <?php echo e($request->document_title ?? 'N/A'); ?>

                    </div>
                    <div class="col-md-6">
                        Date Requested : <?php echo e(date('M d, Y', strtotime($request->created_at)) ?? 'N/A'); ?>

                    </div>
                    <div class="col-md-6">
                        Requested by : <?php echo e($request->user->name); ?>

                    </div>
                </div>

                <hr>
                <div class="row">
                    <div class="col-md-12">
                        Request Type : <b><?php echo e($request->type_of_request ?? 'N/A'); ?></b>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        Reason for changes : <b><?php echo e($request->reason_of_request); ?></b>
                    </div>
                </div>

                <div class="row m-t-md">
                    <div class="col-md-12">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <?php if($request->type_of_request != "Revision"): ?>
                                    Descriptions/Remarks
                                <?php else: ?>
                                    Reason/s for Change
                                <?php endif; ?>
                            </div>
                            <div class="panel-body">
                                <?php echo nl2br(e($request->document_description)); ?>

                            </div>
                        </div>
                    </div>
                </div>

                <hr>
                <div class="row m-t-md">
                    <div class="col-md-12">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                Request History
                            </div>
                            <div class="panel-body">
                                <ul class="nav nav-tabs" role="tablist">
                                    <li class="active" role="presentation">
                                        <a href="#prr-transaction-history-<?php echo e($request->id); ?>" aria-controls="prr-transaction-history-<?php echo e($request->id); ?>" role="tab" data-toggle="tab">
                                            Transaction History
                                        </a>
                                    </li>
                                    <?php if($request->type_of_request === 'Revision' && $request->control_code): ?>
                                        <li role="presentation">
                                            <a href="#prr-related-change-requests-<?php echo e($request->id); ?>" aria-controls="prr-related-change-requests-<?php echo e($request->id); ?>" role="tab" data-toggle="tab">
                                                Related Change Requests
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                                <div class="tab-content m-t-md">
                                    <div class="tab-pane active" id="prr-transaction-history-<?php echo e($request->id); ?>" role="tabpanel">
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped historyTables">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Action</th>
                                                        <th>Action by</th>
                                                        <th>Remarks</th>
                                                        <th>Date Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $request->transactionHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($index + 1); ?></td>
                                                            <td><?php echo e($history->action ?? 'N/A'); ?></td>
                                                            <td><?php echo e($history->user->name ?? 'N/A'); ?></td>
                                                            <td><?php echo e($history->remarks ?? 'N/A'); ?></td>
                                                            <td><?php echo e($history->created_at ? $history->created_at->format('M d, Y h:i A') : 'N/A'); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <?php if($request->type_of_request === 'Revision' && $request->control_code): ?>
                                        <div class="tab-pane" id="prr-related-change-requests-<?php echo e($request->id); ?>" role="tabpanel">
                                            <?php if($request->changeRequest->isNotEmpty()): ?>
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-striped revisionTables" style="width: 100%;">
                                                        <thead>
                                                            <tr>
                                                                <th>Control Code</th>
                                                                <th>Title</th>
                                                                <th>Type of Request</th>
                                                                <th>Requested Date</th>
                                                                <th>Requestor</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $request->changeRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $changeRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($changeRequest->control_code); ?></td>
                                                                    <td><?php echo e($changeRequest->title ?? 'N/A'); ?></td>
                                                                    <td><?php echo e($changeRequest->request_type ?? 'N/A'); ?></td>
                                                                    <td><?php echo e($changeRequest->created_at ? $changeRequest->created_at->format('M d, Y') : 'N/A'); ?></td>
                                                                    <td><?php echo e(optional($changeRequest->user)->name ?? 'N/A'); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            <?php else: ?>
                                                <p class="text-center">No change requests found for this control code.</p>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
