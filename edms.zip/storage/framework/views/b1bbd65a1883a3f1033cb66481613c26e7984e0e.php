
<div class="modal" id="copyRequest" tabindex="-1" role="dialog"  >
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class='col-md-10'>
                    <h5 class="modal-title" id="exampleModalLabel">Copy Request</h5>
                </div>
                <div class='col-md-2'>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            <?php
                $submit = 0; 
            ?>
            <form method='post' action='<?php echo e(url('copy-request')); ?>' onsubmit='show();' class="form-horizontal"  enctype="multipart/form-data" >
                <div class="modal-body">
                        <input type="hidden" class="form-control-sm form-control " name="id" value='<?php echo e($document->id); ?>'  />
                        <input type="hidden" class="form-control-sm form-control " name="control_code" value='<?php echo e($document->control_code); ?>'  />
                        <input type="hidden" class="form-control-sm form-control " name="title" value='<?php echo e($document->title); ?>'  />
                        <input type="hidden" class="form-control-sm form-control " name="revision" value='<?php echo e($document->version); ?>'  />
                        
                    <?php if(count($document->department->dco) > 0): ?>
                        <?php $__currentLoopData = $document->department->dco; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="dco[]" value="<?php echo e($dco->user_id); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class='row '>
                        <?php echo e(csrf_field()); ?>

                        <div class='col-md-4 border'>
                            Control No.
                        </div>
                        <div class='col-md-4 border border-primary'>
                            Document Title
                        </div>
                        <div class='col-md-4 border border-primary'>
                            Revision No
                        </div>
                        <div class='col-md-4 border border-primary'>
                            <strong><?php echo e($document->control_code); ?></strong>
                        </div>
                        <div class='col-md-4 border border-primary'>
                            <strong><?php echo e($document->title); ?> </strong>
                        </div>
                        <div class='col-md-4 border border-primary'>
                            <strong><?php echo e($document->version); ?></strong>
                        </div>
                    </div>
                    <div class='row '>
                        <div class='col-md-12 border'>
                            <hr>
                        </div>
                    </div>
                    <div class='row'>
                        <div class='col-md-4'>
                            Type of Document :
                            <input type="text" class="form-control-sm form-control " name="type_of_document" value='E-Copy' readonly required/>
                            
                        </div>
                        <div class='col-md-4' >
                            Number of Copy :
                            <input type="text" class="form-control-sm form-control " id='number_copy' name="name" value='1' readonly required/>
                        </div>
                        <div class='col-md-4' >
                            Date Needed :
                            <input type="date" class="form-control-sm form-control " min='<?php echo e(date('Y-m-d')); ?>' name="date_needed" required/>
                        </div>
                    </div>
                    <div class='row'>
                        <div class='col-md-12'>
                            Purpose :
                            <textarea name='purpose'  rows="5" cols="100" charswidth="23" class="form-control-sm form-control " required></textarea>
                            
                        </div>
                    </div>
                    <div class='row '>
                        <div class='col-md-12 border'>
                            <hr>
                        </div>
                    </div>
                    <div class='row'>
                        <div class='col-md-6'>
                            Requestor : <?php echo e(auth()->user()->name); ?>

                        </div>
                        <div class='col-md-6'>
                            Immediate Head : 
                            <?php if(auth()->user()->department->dep_head != null): ?>
                                <?php echo e(auth()->user()->department->dep_head->name); ?>

                            <input type='hidden' name='immediate_head' value='<?php echo e(auth()->user()->department->user_id); ?>'>
                            <?php else: ?> 
                                <?php $submit = 1; 
                                ?> No Head
                                 <br> <span class='text-danger'>Please contact Administrator to update your Immediate Head</span> 
                            <?php endif; ?>
                        </div>
                        <div class='col-md-6'>
                            Document Department Head: 
                            <?php if($document->department->dep_head != null): ?>
                                <?php echo e($document->department->dep_head->name); ?>

                                <input type='hidden' name='immediate_head_document' value='<?php echo e($document->department->dep_head->id); ?>'>
                            <?php else: ?> 
                                <?php $submit = 1; ?>
                                No Head
                                <br>
                                <span class='text-danger'>Please contact Administrator to update the Immediate Head of the document's department.</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type='submit'  class="btn btn-primary" <?php if($submit==1): ?> disabled <?php endif; ?> >Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    function select_type(value)
    {
        if(value == "Hard Copy")
        {
            document.getElementById("number_copy").readOnly = false;
            document.getElementById("number_copy").value = "1";
        }
        else
        {
            document.getElementById("number_copy").readOnly = true;
            document.getElementById("number_copy").value = "1";
        }
    }
</script>
