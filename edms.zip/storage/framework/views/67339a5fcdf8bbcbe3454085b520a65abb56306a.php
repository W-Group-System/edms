<div class="modal fade" id="editMajorProcessModal<?php echo e($major_process->id); ?>" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">New Setup</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            <form method="post" action="<?php echo e(url('/new-policy-edit')); ?>" onsubmit="show();" class="form-horizontal" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="modal-body">
                    <div class="border p-3 rounded mb-3">
                        <div class="form-group mb-2">
                            <label>Process Name :</label>
                            <select name="process_id[<?php echo e($major_process->id); ?>]" class="form-control form-control-sm cat">
                                <option value=""></option>
                                <?php $__currentLoopData = $processes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($process->id); ?>" 
                                        <?php echo e($major_process->id == $process->id ? 'selected' : ''); ?>>
                                        <?php echo e($process->process_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <input type="hidden" name="major_process_id[<?php echo e($major_process->id); ?>]" value="<?php echo e($major_process->id); ?>">

                    <div id="policyContainerEdit<?php echo e($major_process->id); ?>">
                        <?php $__currentLoopData = $major_process->policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="policyRow border p-3 rounded mb-3" data-policy-id="<?php echo e($policy->id); ?>">
                            <input type="hidden" name="policy_row_id[<?php echo e($major_process->id); ?>][]" value="<?php echo e($policy->id); ?>">
                            <div class="form-group mb-2">
                                <label>Policy :</label>
                                <select name="policy_id[<?php echo e($major_process->id); ?>][]" class="form-control form-control-sm cat">
                                    <option value=""></option>
                                    <?php $__currentLoopData = $major_process->available_documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($document->id); ?>" 
                                            <?php echo e($policy->policy_id == $document->id ? 'selected' : ''); ?>>
                                            <?php echo e($document->control_code); ?> - <?php echo e($document->title); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="subPolicyWrapperEdit mb-2">
                                <button type="button" class="btn btn-secondary btn-sm addSubPolicyBtn mb-2">+ Add Sub Policy</button>

                                <div class="subpolicyContainerEdit mt-2">
                                    <?php $__currentLoopData = $policy->annexes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subPolicy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:6px;">
                                        <input type="hidden" name="sub_policy_row_id[<?php echo e($policy->id); ?>][]" value="<?php echo e($subPolicy->id); ?>">
                                        <tr>
                                            <td style="width:95%;">
                                                <select name="sub_policy_id[<?php echo e($policy->id); ?>][]" class="form-control form-control-sm cat">
                                                    <option value=""></option>
                                                    <?php $__currentLoopData = $major_process->available_documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($document->id); ?>"
                                                            <?php echo e($subPolicy->document_id == $document->id ? 'selected' : ''); ?>>
                                                            <?php echo e($document->control_code); ?> - <?php echo e($document->title); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td style="width:5%; text-align:center;">
                                                <button type="button" class="btn btn-danger btn-sm removeSubPolicyBtn" data-subpolicy-id="<?php echo e($subPolicy->id); ?>">×</button>
                                            </td>
                                        </tr>
                                    </table>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <button type="button" class="btn btn-danger btn-sm removePolicyEditButton mt-2">Remove Policy</button>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <button type="button" class="btn btn-primary btn-sm mb-2 addPolicyBtnEdit" data-modal-id="<?php echo e($major_process->id); ?>">+ Add Policy</button>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
                    <button class="btn btn-primary" type="submit">Submit</button>
                </div>

                <div id="deletedSubPoliciesContainer">
                    <input type="hidden" name="deleted_sub_policies[]" id="deleted_sub_policies_input">
                </div>
            </form>
        </div>
    </div>
</div>