<?php if(count($errors)): ?>
 
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class='row mb-3'>
            <div class="col-lg-12 bg-danger p-xs b-r-sm"> <strong>Error!</strong> <?php echo e($error); ?></div>
        </div>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>