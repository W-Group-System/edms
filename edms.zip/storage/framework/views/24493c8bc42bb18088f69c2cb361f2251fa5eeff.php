<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('login_css/css/plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Total</h5>
                </div>
                <div class="ibox-content">
                    
                    <h1 class="no-margins">
                        
                        <a href="<?php echo e(url('permits')); ?>"><?php echo e($permits_count); ?></a>
                    </h1>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Active</h5>
                </div>
                <div class="ibox-content">
                    <form action="" method="get">
                        
                        <h1 class="no-margins">
                            <input type="hidden" name="active_permits_filter" value="Active">
                            <input type="submit" value="<?php echo e($active_permits_count); ?>" style="background: none; border: none;" class="text-success">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>For Renewal</h5>
                </div>
                <div class="ibox-content">
                    <form action="" method="get">
                        
                        <h1 class="no-margins">
                            <input type="hidden" name="renewal_filter" value="For Renewal">
                            
                            <input type="submit" value="<?php echo e($for_renewal_count); ?>" style="background: none; border: none;" class="text-success">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Overdue</h5>
                </div>
                <div class="ibox-content">
                    
                    <form method="GET">
                        <h1 class="no-margins">
                            <input type="hidden" name="overdue_filter" value="Overdue">
                            
                            <input type="submit" value="<?php echo e($overdue_count); ?>" style="background: none; border: none;" class="text-success">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Archived</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins">
                        <a href="<?php echo e(url('archive_permits')); ?>"><?php echo e(count($archives)); ?></a>
                    </h1>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Inactive</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins">
                        <form method="GET">
                            <h1 class="no-margins">
                                <input type="hidden" name="inactive_filter" value="Inactive">
                                
                                <input type="submit" value="<?php echo e($inactive_permits_count); ?>" style="background: none; border: none;" class="text-success">
                            </h1>
                        </form>
                    </h1>
                </div>
            </div>
        </div>
    </div>
    <div class='row'>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Permits & Licenses <button class="btn btn-success "  data-target="#new_permit" data-toggle="modal" type="button"><i class="fa fa-plus"></i>&nbsp;New </button></h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Company</th>
                                    <th>Department</th>
                                    <th>Accountable Person</th>
                                    <th>Date Uploaded</th>
                                    <th>File</th>
                                    <th>Type</th>
                                    <th>Expiration Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $permits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($permit->title); ?></td>
                                    <td><?php echo e($permit->description); ?></td>
                                    <td><?php echo e($permit->company->name); ?></td>
                                    <td><?php echo e($permit->department->name); ?></td>
                                    <td><small><?php $__currentLoopData = $permit->department->permit_accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accountable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($accountable->user->name); ?> <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></small></td>
                                    <td><?php echo e(date('M d, Y',strtotime($permit->created_at))); ?></td>
                                    <td><a href='<?php echo e(url($permit->file)); ?>' target='_blank'><i class='fa fa-file'></i></a></td>
                                    <td><?php echo e($permit->type); ?></td>
                                    <td><?php if($permit->expiration_date != null): ?><?php echo e(date('M d Y',strtotime($permit->expiration_date))); ?><?php endif; ?></td>
                                    <td>
                                        <?php if($permit->status != null): ?>
                                            <?php if($permit->status == "Inactive"): ?>
                                            <small class="label label-danger"><?php echo e($permit->status); ?></small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if($permit->expiration_date != null): ?>
                                                <?php if($permit->expiration_date < date("Y-m-d")): ?> 
                                                <small class="label label-danger">For Renewal (Overdue)</small> 
                                                <?php elseif($permit->expiration_date < date('Y-m-d', strtotime("+3 months", strtotime(date('Y-m-d'))))): ?> 
                                                <small class="label label-warning">For Renewal</small> 
                                                <?php else: ?> 
                                                <small class="label label-primary">Active</small> 
                                                <?php endif; ?> 
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        
                                        <button class="btn btn-sm btn-primary "  title="Upload " data-target="#upload<?php echo e($permit->id); ?>" data-toggle="modal"><i class="fa fa-upload"></i></button>
                                       <?php if((auth()->user()->role != "User") && (auth()->user()->role != "Department Head") && (auth()->user()->role != "Documents and Records Controller") ): ?>
                                       <button class="btn btn-sm btn-warning "  title="Transfer Department" data-target="#change<?php echo e($permit->id); ?>" data-toggle="modal"><i class="fa fa-users"></i></button>
                                       <button class="btn btn-sm btn-info "  title="Change Types" data-target="#changeType<?php echo e($permit->id); ?>" data-toggle="modal"><i class="fa fa-edit"></i></button>
                                       <?php if($permit->status == null): ?>
                                       <form method="POST" action="<?php echo e(url('inactive-permits/'.$permit->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                           <button class="btn btn-sm btn-danger inactiveBtn" type="button" title="Inactive Permits">
                                                <i class="fa fa-trash"></i>
                                           </button>
                                       </form>
                                       <?php endif; ?>
                                       <?php if($permit->status == "Inactive"): ?>
                                       <form method="POST" action="<?php echo e(url('activate-permits/'.$permit->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                           <button class="btn btn-sm btn-success activatePermitsBtn" type="button" title="Activate Permits">
                                                <i class="fa fa-check"></i>
                                           </button>
                                       </form>
                                       <?php endif; ?>
                                       <?php endif; ?>
                                        
                                    </td>
                                </tr>
                                <?php echo $__env->make('upload_permit', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php echo $__env->make('transfer_department', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php echo $__env->make('edit_type', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>
<?php echo $__env->make('new_permit', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/sweetalert/sweetalert.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        
        $('.cat').chosen({width: "100%"});
        $('.locations').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            stateSave: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

        $('.inactiveBtn').on('click', function() {
            swal({
                title: "Are you sure?",
                text: "This permits will be inactive!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, Inactive it!",
                closeOnConfirm: false
            }, function (){
                $('.inactiveBtn').closest('form').submit()
            });
        })

        $('.activatePermitsBtn').on('click', function() {
            
            swal({
                title: "Are you sure?",
                text: "This permits will be activate!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, Activate it!",
                closeOnConfirm: false
            }, function (){
                $('.activatePermitsBtn').closest('form').submit()
            });
        })
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>