<?php $__env->startSection('content'); ?>
<div class="limiter">
    <div class="container-login100">
        <div class="wrap-login100">
            <form method="POST" action="<?php echo e(route('login')); ?>"  class="login100-form validate-form" onsubmit='show()'>
                <?php echo csrf_field(); ?>
             
                <span class="login100-form-title p-b-43">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </span>
                <span class="login100-form-title p-b-43">
                    <h6>Login to continue</h6>
                </span>
                
                <?php if($errors->any()): ?>
                <div class="form-group alert alert-danger alert-dismissable">
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    <strong><?php echo e($errors->first()); ?></strong>
                </div>
            <?php endif; ?>
                <div class="wrap-input100" data-validate = "Valid email is required: ex@abc.xyz">
                    <input  type="email" class="input100" name="email" value="" required >
                    <span class="focus-input100"></span>
                    <span class="label-input100">Email</span>
                </div>
                
                
                <div class="wrap-input100" data-validate="Password is required">
                    <input  id="password" type="password" class="input100" name="password" required>
                    <span class="focus-input100"></span>
                    <span class="label-input100">Password</span>
                </div>

                <div class="container-login100-form-btn">
                    <button class="login100-form-btn" type='submit'>
                        Login
                    </button>
                </div>
                <div class="flex-sb-m w-full p-t-3 p-b-32">

                    <div>
                        <a href="<?php echo e(route('password.request')); ?>" class="txt1">
                            Forgot Password?
                        </a>
                    </div>
                </div>
        

                
                
            </form>

            <div class="login100-more" style="background-image: url('login_design/images/WGROUP.png');">
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>