<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper wrapper-content">
    <div class="row">
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Pending</h5>
                </div>
                
                <div class="ibox-content">
                    <form method="GET">
                        <h1 class="no-margins">
                            <input type="hidden" name="status" value="NotDelayed">
                            <input type="submit" class="text-success" value="<?php echo e($notDelayedCount); ?>" style="background: none; border: none;">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Declined</h5>
                </div>
                <div class="ibox-content">
                    <form method="GET">
                        <h1 class="no-margins">
                            <input type="hidden" name="status" value="Declined">
                            <input type="submit" class="text-success" value="<?php echo e($declinedCount); ?>" style="background: none; border: none;">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Approved</h5>
                </div>
                <div class="ibox-content">
                    <form method="GET">
                        <h1 class="no-margins">
                            <input type="hidden" name="status" value="Approved">
                            <input type="submit" class="text-success" value="<?php echo e($approvedCount); ?>" style="background: none; border: none;">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Delayed</h5>
                </div>
                <div class="ibox-content">
                    <form method="GET">
                        <h1 class="no-margins">
                            <input type="hidden" name="status" value="Delayed">
                            <input type="submit" class="text-success" value="<?php echo e($delayedCount); ?>" style="background: none; border: none;">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Pre-Assessment Returned</h5>
                </div>
                <div class="ibox-content">
                    <form method="GET">
                        <h1 class="no-margins">
                            <input type="hidden" name="status" value="Pre-Assessment Returned">
                            <input type="submit" class="text-success" value="<?php echo e($returnedCount); ?>" style="background: none; border: none;">
                        </h1>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class='row'>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Pre Assessment</h5>
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                            <thead>
                                <tr>
                                    
                                    <th>Actions</th>
                                    
                                    <th>Date Requested</th>
                                    <th>Code</th>
                                    <th>Title</th>
                                    <th>Revision</th>
                                    <th>Type</th>
                                    <th>Requested By</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $delayed = 0;
                                ?>
                                <?php $__currentLoopData = $pre_assessment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $targetDate = date('Y-m-d', strtotime('+10 days', strtotime($pa->created_at)));
                                    ?>
                                    <tr>
                                        
                                        <td>
                                            <button type="button" data-target="#viewPreAssessmentModal-<?php echo e($pa->id); ?>" data-toggle="modal" class='btn btn-sm btn-info'>
                                                <i class="fa fa-eye"></i>
                                            </button>
                                        </td>
                                        
                                        <td><?php echo e(date('M d Y',strtotime($pa->created_at))); ?></td>
                                        <td><?php echo e($pa->control_code); ?></td>
                                        <td><?php echo e($pa->title); ?></td>
                                        <td><?php echo e($pa->revision); ?></td>
                                        <td><?php echo e($pa->type_of_document); ?></td>
                                        <td><?php echo e($pa->user->name); ?></td>
                                        <td> 
                                            <?php if($pa->status == "Pending"): ?>
                                                <?php if($targetDate < date('Y-m-d')): ?>
                                                    <?php
                                                        $delayed++;
                                                    ?>
                                                    <span class='label label-danger'>
                                                        Delayed - 
                                                <?php else: ?>
                                                    <span class='label label-success'>
                                                <?php endif; ?>
                                            <?php elseif($pa->status ==  "Approved"): ?>
                                                <span class='label label-info'>    
                                            <?php elseif($pa->status ==  "Declined"): ?>
                                                <span class='label label-warning'>
                                            <?php elseif($pa->status ==  "Pre-Assessment Returned"): ?>
                                                <span class='label label-warning'>
                                            <?php else: ?>
                                                <span class='label label-success'>
                                            <?php endif; ?>
                                            <?php echo e($pa->status); ?></span>  
                                        </td>
                                    </tr>
                                    <?php echo $__env->make('view_pre_assessment', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script>
    $(document).ready(function(){
        // var delayed = <?php echo json_encode($delayed); ?>;
        // document.getElementById('delayed').innerText = delayed;

        $('.cat').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            sorting:false,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                {extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                    customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                    }
                }
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>