<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('login_css/css/plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Companies</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($companies)); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Active</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($companies->where('status',null))); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Deactivated</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($companies->where('status','!=',null))); ?></h1>
                </div>
            </div>
        </div>
        
    </div>
    <div class='row'>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Company <button class="btn btn-success "  data-target="#new_company" data-toggle="modal" type="button"><i class="fa fa-plus"></i>&nbsp;New </button></h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Code</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($company->name); ?></td>
                                <td><?php echo e($company->code); ?></td>
                                <td id='statuscompanytd<?php echo e($company->id); ?>'><?php if($company->status): ?> <small class="label label-danger">Inactive</small>  <?php else: ?> <small class="label label-primary">Active</small> <?php endif; ?></td>
                                <td data-id='<?php echo e($company->id); ?>' id='actioncompanytd<?php echo e($company->id); ?>'>
                                    <?php if($company->status): ?>
                                    <button class="btn btn-sm btn-primary activate-company" id='<?php echo e($company->id); ?>' title="Activate"><i class="fa fa-check"></i></button>
                                    <?php else: ?>
                                    
                                    <button class="btn btn-sm btn-danger deactivate-company" id='<?php echo e($company->id); ?>' title='Deactivate' ><i class="fa fa-trash"></i></button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>
<?php echo $__env->make('new_company', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/sweetalert/sweetalert.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        $('.deactivate-company').click(function () {
        
        var id = this.id;
            swal({
                title: "Are you sure?",
                text: "This company will be deactivated!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, deactivated it!",
                closeOnConfirm: false
            }, function (){
                $.ajax({
                    dataType: 'json',
                    type:'POST',
                    url:  '<?php echo e(url("deactivate-company")); ?>',
                    data:{id:id},
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                }).done(function(data){
                    console.log(data);
                    swal("Deactivated!", "Company is now deactivated.", "success");
                    location.reload();
                }).fail(function(data)
                {
                    
                    swal("Deactivated!", "Company is now deactivated.", "success");
                location.reload();
                });
            });
        });
        $('.activate-company').click(function () {
        
        var id = this.id;
            swal({
                title: "Are you sure?",
                text: "This company will be activated!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, Activated it!",
                closeOnConfirm: false
            }, function (){
                $.ajax({
                    dataType: 'json',
                    type:'POST',
                    url:  '<?php echo e(url("activate-company")); ?>',
                    data:{id:id},
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                }).done(function(data){
                    console.log(data);
                    swal("Activated!", "Company is now activated.", "success");
                    location.reload();
                }).fail(function(data)
                {
                    
                    swal("Activated!", "Company is now activated.", "success");
                location.reload();
                });
            });
        });

        $('.locations').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>