
<div class="modal" id="view_request<?php echo e($request->id); ?>" tabindex="-1" role="dialog"  >
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class='col-md-10'>
                    <h5 class="modal-title" id="exampleModalLabel">View Copy Request (<?php echo e($request->status); ?>)</h5>
                </div>
                <div class='col-md-2'>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
                <div class="modal-body">
                    <div class='row '>
                        <div class='col-md-6'>
                            Reference Number : <b>CR-<?php echo e(str_pad($request->id, 5, '0', STR_PAD_LEFT)); ?></b>
                        </div>
                        <div class='col-md-6'>
                            Type of Document : <?php echo e($request->type_of_document); ?>

                        </div>
                        <div class='col-md-6'>
                            Date Needed : <?php echo e(date('M d Y',strtotime($request->date_needed))); ?>

                        </div>
                        <div class='col-md-6'>
                           Copy Needed : <?php echo e($request->copy_count); ?>

                        </div>
                    </div>
                    <hr>
                    <div class='row '>
                        <div class='col-md-6'>
                            Control Code : <?php echo e($request->control_code); ?> Rev. <?php echo e($request->revision); ?>

                        </div>
                        <div class='col-md-6'>
                            Title : <?php echo e($request->title); ?>

                        </div>
                    </div>
                    <div class='row '>
                        <div class='col-md-6'>
                            Requested By : <?php echo e($request->user->name); ?> 
                        </div>
                        <div class='col-md-6'>
                            Date Requested : <?php echo e(date('M d, Y',strtotime($request->created_at))); ?>

                        </div>
                    </div>
                    <div class='row '>
                        <div class='col-md-12'>
                            Purpose : <?php echo e($request->purpose); ?> 
                        </div>
                    </div>
                    <hr>
                    <div class='row text-center'>
                        <div class='col-md-3 border  border-primary border-top-bottom border-left-right'>
                           Approver
                        </div>
                        <div class='col-md-3 border  border-primary border-top-bottom border-left-right'>
                           Status
                        </div>
                        <div class='col-md-2 border  border-primary border-top-bottom border-left-right'>
                           Start Date
                        </div>
                        <div class='col-md-2 border  border-primary border-top-bottom border-left-right'>
                           Action Date
                        </div>
                        <div class='col-md-2 border  border-primary border-top-bottom border-left-right'>
                           Remarks
                        </div>
                    </div>
                    <?php $__currentLoopData = $request->approvers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class='row text-left'>
                        <div class='col-md-3 border border-primary border-top-bottom border-left-right'>
                           <?php echo e($approver->user->name); ?>

                        </div>
                        <div class='col-md-3 border border-primary border-top-bottom border-left-right'>
                            <?php echo e($approver->status); ?>

                        </div>
                        <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                            <?php if($approver->start_date != null): ?><?php echo e($approver->start_date); ?><?php endif; ?> &nbsp;
                        </div>
                        <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                            
                            <?php if($approver->status != "Waiting" && $approver->status != "Pending"): ?>
                                <?php echo e(date('Y-m-d',strtotime($approver->updated_at))); ?>

                            <?php endif; ?>
                        </div>
                        <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                            <?php echo nl2br(e($approver->remarks)); ?>&nbsp;
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <?php if($request->status == "Approved"): ?>
                                <?php if(strtotime($request->expiration_date) >= strtotime(date('Y-m-d'))): ?>
                                    <?php if($request->type_of_document == "Hard Copy"): ?>
                                    <div class="panel panel-primary">
                                        <div class="panel-heading">
                                            Hard Copy Request
                                        </div>
                                        <div class="panel-body">
                                            <p>Please get your hard copy from DRC. This request will expire by <?php echo e(date("M. d, Y",strtotime($request->expiration_date))); ?></p>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <?php if($request->document_access): ?>
                                        <div class="panel panel-primary">
                                            <div class="panel-heading">
                                                E-Copy Request, Expiration Date : <?php echo e(date("M. d, Y",strtotime($request->expiration_date))); ?> 
                                                <?php if($request->document_access->attachment != null): ?>
                                                    <?php if(($request->document->category == "FORM") || ($request->document->category == "TEMPLATE")): ?>
                                                        <a href="<?php echo e(url($request->document_access->attachment->attachment)); ?>" target="_blank"><button type="button" class="btn btn-w-m btn-danger">Download</button></a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(url('view-pdf/'.$request->document_access->attachment_id)); ?>" target="_blank"><button type="button" class="btn btn-w-m btn-danger">Download</button></a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                            <div class="panel-body">
                                                <?php if($request->document_access->attachment != null): ?>
                                                    <?php if(($request->document->category == "FORM") || ($request->document->category == "TEMPLATE")): ?>
                                                        <iframe width='100%' height='500px;'  src="<?php echo e(url($request->document_access->attachment->attachment)); ?>" title="Access"></iframe>
                                                    <?php else: ?>
                                                        <iframe width='100%' height='500px;'  src="<?php echo e(url('view-pdf/'.$request->document_access->attachment_id.'?page=hsn#toolbar=0')); ?>" title="Access"></iframe>
                                                    <?php endif; ?>
                                                 <?php endif; ?>
                                                <p></p>
                                            </div>
                                        </div>
                                       <?php endif; ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="panel panel-danger">
                                        <div class="panel-heading">
                                           Expired Request
                                        </div>
                                        <div class="panel-body">
                                            <p>Your request or access to this request is expired. Expiration Date : <?php echo e(date("M. d, Y",strtotime($request->expiration_date))); ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
