<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Total</h5>
                </div>
                <div class="ibox-content">
                    
                    <h1 class="no-margins">
                        <a href="<?php echo e(url('permits')); ?>"><?php echo e(count($permits)); ?></a>
                    </h1>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Active</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins">
                        <a href="<?php echo e(url('permits?active_permits_filter=Active')); ?>"><?php echo e($active_permits_count); ?></a>
                    </h1>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>For Renewal</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins">
                        
                        <a href="<?php echo e(url('permits?renewal_filter=For+Renewal')); ?>"><?php echo e($for_renewal_count); ?></a>
                    </h1>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Overdue</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><a href="<?php echo e(url('permits?overdue_filter=Overdue')); ?>"><?php echo e($overdue_count); ?></a></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Archived</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins">
                        <a href="<?php echo e(url('archive_permits')); ?>"><?php echo e(count($archives)); ?></a>
                    </h1>
                </div>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Inactive</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins">
                        <a href="<?php echo e(url('permits?inactive_filter=Inactive')); ?>"><?php echo e(count($inactive_count)); ?></a>
                    </h1>
                </div>
            </div>
        </div>
    </div>
    <div class='row'>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    
                    <h5>Permits & Licenses</h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Company</th>
                                    <th>Department</th>
                                    <th>Accountable Person</th>
                                    <th>Date Uploaded</th>
                                    <th>File</th>
                                    <th>Type</th>
                                    <th>Expiration Date</th>
                                    <th>Status</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $archives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($archive->title); ?></td>
                                    <td><?php echo e($archive->description); ?></td>
                                    <td>
                                        <?php echo e($archive->company->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($archive->department->name); ?>

                                    </td>
                                    <td>
                                        <small>
                                            <?php $__currentLoopData = $archive->department->permit_accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accountable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($accountable->user->name); ?> <hr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </small>
                                    </td>
                                    <td><?php echo e(date('M d, Y',strtotime($archive->created_at))); ?></td>
                                    <td>
                                        <a href='<?php echo e(url($archive->file)); ?>' target='_blank'><i class='fa fa-file'></i></a>
                                    </td>
                                    <td><?php echo e($archive->type); ?></td>
                                    <td><?php if($archive->expiration_date != null): ?><?php echo e(date('M d Y',strtotime($archive->expiration_date))); ?><?php endif; ?></td>
                                    <td>
                                        
                                        <div class="label label-danger">Obsolete</div>
                                    </td>
                                    
                                </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script>
    $(document).ready(function(){
        
        $('.cat').chosen({width: "100%"});
        $('.locations').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            stateSave: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>