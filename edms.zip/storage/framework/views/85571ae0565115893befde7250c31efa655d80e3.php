<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   
    <div class="row">
        <div class="col-lg-12">
            <div class="wrapper wrapper-content ">
                <div class="ibox">
                    <div class="ibox-title">
                        
                        <h5><?php echo e($document->title); ?> </h5>
                        
                        <?php if($document->status == null): ?><span class="label label-primary">Active</span>  <?php else: ?><span class="label label-danger">Obsolete</span> <?php endif; ?>
                        <div class='float-right text-right'>
                            <?php if(auth()->user()->role == "Document Control Officer"): ?>
                        <button class="btn btn-sm btn-info "  title='Edit' data-target="#edit_document" data-toggle="modal"><i class="fa fa-edit"></i></button> 
                        <?php endif; ?>
                        </div>
                    </div>
                    <div class="ibox-content">
                        
                        <?php if($document->status != "Obsolete"): ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="m-b-md">
                                        <?php if((auth()->user()->role == "User") || (auth()->user()->role == "Documents and Records Controller") || (auth()->user()->role == "Document Control Officer") || (auth()->user()->role == "Department Head")): ?>
                                            <?php if($document->department_id == 8): ?>
                                                <a href="#" data-target="#changeRequest" data-toggle="modal" class="btn btn-warning btn-sm ">Change Request </a>
                                                <a href="#"  data-target="#obsoleteRequest" data-toggle="modal"  class="btn btn-danger btn-sm ">Obsolete Request </a>
                                            <?php endif; ?> 
                                            <?php if(auth()->user()->role == "Documents and Records Controller"): ?>
                                                <?php if(auth()->user()->department_id != $document->department_id): ?>
                                                    <?php if(auth()->user()->audit_role == null): ?>
                                                        <a href="#" data-target="#copyRequest" data-toggle="modal"  class="btn btn-success btn-sm ">Copy Request </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php elseif(auth()->user()->role == "Document Control Officer"): ?> 
                                                <?php
                                                    $dep = (auth()->user()->dco)->where('department_id',$document->department_id);
                                                ?>
                                                <?php if(count($dep) == 0): ?>
                                                    <?php if(auth()->user()->audit_role == null): ?>
                                                        <a href="#" data-target="#copyRequest" data-toggle="modal"  class="btn btn-success btn-sm ">Copy Request </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php elseif(auth()->user()->role == "Department Head"): ?>
                                                <?php
                                                    $depd = 0;
                                                ?>
                                                <?php $__currentLoopData = auth()->user()->department_head; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($dep->id == $document->department_id): ?>
                                                        <?php
                                                                $depd = 1;
                                                        ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($depd == 0): ?>
                                                    <?php if(auth()->user()->audit_role == null): ?>
                                                        <a href="#" data-target="#copyRequest" data-toggle="modal"  class="btn btn-success btn-sm ">Copy Request </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if(auth()->user()->audit_role == null): ?>
                                                    <a href="#" data-target="#copyRequest" data-toggle="modal"  class="btn btn-success btn-sm ">Copy Request </a>
                                                    <?php if($document->department_id == auth()->user()->department_id): ?>
                                                    <a href="#" data-target="#changeRequest" data-toggle="modal" class="btn btn-warning btn-sm ">Change Request </a>
                                                    <a href="#"  data-target="#obsoleteRequest" data-toggle="modal"  class="btn btn-danger btn-sm ">Obsolete Request </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php if(auth()->user()->role == "Documents and Records Controller"): ?>
                                        <?php if(auth()->user()->department_id == $document->department_id): ?>
                                            <a href="#" data-target="#changeRequest" data-toggle="modal" class="btn btn-warning btn-sm ">Change Request </a>
                                            <a href="#"  data-target="#obsoleteRequest" data-toggle="modal"  class="btn btn-danger btn-sm ">Obsolete Request </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->role == "Document Control Officer"): ?>
                                        <?php
                                            $dep = (auth()->user()->dco)->where('department_id',$document->department_id);
                                        ?>
                                        <?php if(count($dep) == 1): ?>
                                            
                                            <a href="#"  data-target="#obsoleteRequest" data-toggle="modal"  class="btn btn-danger btn-sm ">Obsolete Request </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        </div>
                        
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <dl class="dl-horizontal">
                                    <dt>Uploaded by:</dt> <dd><?php echo e($document->user->name); ?></dd>
                                    <dt>Control Code:</dt> <dd>  <?php echo e($document->control_code); ?></dd>
                                    <dt>Revisions:</dt> <dd>  <?php echo e($document->version); ?></dd>
                                    <dt>Type of Document:</dt> <dd>  <?php echo e($document->category); ?></dd>
                                    <dt>Company:</dt> <dd><?php echo e($document->company->name); ?></dd>
                                    <dt>Department:</dt> <dd> 	<?php echo e($document->department->name); ?></dd>
                                    <dt>Department Head:</dt> <dd> 	<?php if($document->department->dep_head): ?><?php echo e($document->department->dep_head->name); ?><?php else: ?> <small class='label label-danger'>No Department Head</small><?php endif; ?></dd>
                                </dl>
                            </div>
                            <div class="col-lg-6" >
                                <dl class="dl-horizontal" >

                                    <dt>Created:</dt> <dd> 	<?php echo e(date('M, d Y',strtotime($document->created_at))); ?> </dd>
                                    <dt>Effective Updated:</dt> <dd><?php echo e(date('M, d Y',strtotime($document->updated_at))); ?></dd>
                                    
                                    
                                    <dt>Process Owner:</dt> <dd><?php if($document->process_owner != null): ?> <small class="label label-info"><?php echo e($document->processOwner->name); ?></small> <?php else: ?> <small class="label label-info"><?php echo e($document->department->dep_head->name); ?></small> <?php endif; ?></dd>
                                    
                                </dl>
                            </div>
                        </div>
                        
                        <?php
                            $allow = 0;
                        ?>
                        <?php $__currentLoopData = $document->department->drc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($drc->id == auth()->user()->id): ?>
                                <?php
                                        $allow = 1;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = auth()->user()->department_head; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dep->id == $document->department_id): ?>
                                <?php
                                        $allow = 1;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $document->department->dco; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dco->user_id == auth()->user()->id): ?>
                                <?php
                                        $allow = 1;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $document->department->departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($depa->user_id == auth()->user()->id): ?>
                                <?php
                                        $allow = 1;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if((auth()->user()->role == "Administrator") || (auth()->user()->role == "Business Process Manager") || (auth()->user()->role == "Management Representative")): ?>
                            <?php
                                $allow = 1;
                            ?>
                        <?php endif; ?>
                        <?php $__currentLoopData = auth()->user()->department_head; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($head->user_id == $document->department_id): ?>
                                <?php
                                        $allow = 1;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if((auth()->user()->audit_role != null)): ?>
                                <?php
                                    $allow = 1;
                                ?>
                        <?php endif; ?>
                        <?php
                        if(auth()->user()->department_id == $document->department_id)
                        {
                            $allow =1;
                        }
                        ?>
                        <?php if($allow == 1): ?>
                        
                        <div class="row">
                            <div class="col-lg-12">
                                <dl class="dl-horizontal">

                                    <dt>Attachments</dt>
                                        <?php $__currentLoopData = $document->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($attachment->attachment != null): ?>
                                                <?php if(($attachment->type == "soft_copy") && ($document->department_id == 8)): ?>
                                                <dd><a href='<?php echo e(url($attachment->attachment)); ?>' target="_blank" ><i class="fa fa-file-word-o"></i> Editable Copy</a> 
                                                    <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Business Process Manager') || (auth()->user()->role == 'Management Representative') || (auth()->user()->role == "Document Control Officer")): ?>
                                                    <a href='#' class='text-danger'  data-target="#edit<?php echo e($attachment->id); ?>"  data-toggle="modal" ><i class="fa fa-edit"></i> </a>
                                                    <?php endif; ?>
                                                </dd>
                                                <?php endif; ?>
                                                <?php if(($attachment->type == "soft_copy") && (auth()->user()->audit_role == null)): ?>
                                                <dd><a href='<?php echo e(url($attachment->attachment)); ?>' target="_blank" ><i class="fa fa-file-word-o"></i> Editable Copy</a> 
                                                    <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Business Process Manager') || (auth()->user()->role == 'Management Representative') || (auth()->user()->role == "Document Control Officer")): ?>
                                                    <a href='#' class='text-danger'  data-target="#edit<?php echo e($attachment->id); ?>"  data-toggle="modal" ><i class="fa fa-edit"></i> </a>
                                                    <?php endif; ?>
                                                </dd>
                                                <?php elseif($attachment->type == "pdf_copy"): ?>
                                                    <?php if(($document->category == "FORM") || ($document->category == "TEMPLATE")): ?>
                                                    <dd><a href='<?php echo e(url($attachment->attachment)); ?>' target="_blank" ><i class="fa fa-file-pdf-o"></i> PDF Copy</a>    <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Business Process Manager') || (auth()->user()->role == 'Management Representative') || (auth()->user()->role == "Document Control Officer")): ?>
                                                        <a href='#' class='text-danger'  data-target="#edit<?php echo e($attachment->id); ?>" data-toggle="modal"  ><i class="fa fa-edit"></i> </a>
                                                        <?php endif; ?></dd>
                                                    <?php else: ?>
                                                    <dd><a href='<?php echo e(url('view-pdf/'.$attachment->id)); ?>' target="_blank" ><i class="fa fa-file-pdf-o"></i> PDF Copy</a>    <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Business Process Manager') || (auth()->user()->role == 'Management Representative') || (auth()->user()->role == "Document Control Officer")): ?>
                                                        <a href='#' class='text-danger' data-target="#edit<?php echo e($attachment->id); ?>" data-toggle="modal"   ><i class="fa fa-edit"></i> </a>
                                                        <?php endif; ?></dd>
                                                    <?php endif; ?>
                                                    
                                                <?php else: ?>
                                                <?php if((auth()->user()->audit_role == null)): ?>
                                               
                                                <dd><a href='<?php echo e(url($attachment->attachment)); ?>' target="_blank" ><i class="fa fa-file-pdf-o"></i> Fillable Copy</a></dd>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                            
                                             <?php endif; ?>
                                             <?php echo $__env->make('change_file', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                </dl>
                            </div>
                        </div>
                        
                        <?php if((auth()->user()->audit_role == null)): ?>
                        <div class="row m-t-sm">
                            <div class="col-lg-12">
                            <div class="panel blank-panel">
                            <div class="panel-heading">
                                <div class="panel-options">
                                    <ul class="nav nav-tabs">
                                        <li class="active"><a href="#tab-1" data-toggle="tab">Revisions</a></li>
                                        <li class=""><a href="#tab-2" data-toggle="tab">Change Requests</a></li>
                                        <li class=""><a href="#tab-3" data-toggle="tab">Copy Requests</a></li>
                                        <li class=""><a href="#tab-4" data-toggle="tab">Memo</a></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="panel-body">

                            <div class="tab-content">
                            <div class="tab-pane active" id="tab-1">
                                <table class="table table-striped tables">
                                    <thead>
                                        <tr>
                                            <th>Control Code</th>
                                            <th>Company</th>
                                            <th>Department</th>
                                            <th>Revision</th>
                                            <th>Date Obsolete</th>
                                            <th>Obsolete By</th>
                                            <th>Attachments</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $document->revisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($revision->control_code); ?></td>
                                                <td><?php echo e($revision->company->name); ?></td>
                                                <td><?php echo e($revision->department->name); ?></td>
                                                <td><?php echo e($revision->version); ?></td>
                                                <td><?php echo e(date('M d, Y',strtotime($revision->created_at))); ?></td>
                                                <td><?php echo e($revision->user->name); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $revision->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href='<?php echo e(url($att->attachment)); ?>' target='_blank'><?php echo e($att->type); ?></a>
                                                    <br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="tab-pane" id="tab-2">

                                <table class="table table-striped tables">
                                    <thead>
                                        <tr>
                                            
                                            <th>DICR #</th>
                                            <th>Type of Request</th>
                                            <th>Requested Date</th>
                                            <th>Requestor</th>
                                            <th>Department</th>
                                            <th>Proposed Effective Date</th>
                                            <th>Type of Document</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $document->change_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $change_req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                
                                                <td>DICR-<?php echo e(str_pad($change_req->id, 5, '0', STR_PAD_LEFT)); ?></td>
                                                <td><?php echo e($change_req->request_type); ?></td>
                                                <td><?php echo e(date('M d Y',strtotime($change_req->created_at))); ?></td>
                                                <td><?php echo e($change_req->user->name); ?></td>
                                                <td><?php echo e($change_req->department->name); ?></td>
                                                <td> <?php echo e($change_req->effective_date ? \Carbon\Carbon::parse($change_req->effective_date)->format('M d, Y') : ''); ?></td>
                                                <td><?php echo e($change_req->type_of_document); ?></td>
                                                <td><?php if($change_req->status == "Pending"): ?>
                                                    <span class='label label-warning'>
                                                <?php elseif($change_req->status ==  "Approved"): ?>
                                                    <span class='label label-info'>    
                                                <?php elseif($change_req->status ==  "Declined"): ?>
                                                        <span class='label label-danger'>
                                                <?php else: ?><span class='label label-success'>
                                                    <?php endif; ?>
                                                    <?php echo e($change_req->status); ?></span> </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                            <div class="tab-pane" id="tab-3">

                                <table class="table table-striped tables">
                                    <thead>
                                        <tr>
                                            <th>Reference #</th>
                                            <th>Type of Document</th>
                                            <th>Date Requested</th>
                                            <th>Date Needed</th>
                                            <th>Requestor</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $document->copy_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $copy_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>CR-<?php echo e(str_pad($copy_request->id, 5, '0', STR_PAD_LEFT)); ?></td>
                                            <td><?php echo e($copy_request->type_of_document); ?></td>
                                            <td><?php echo e(date('M d Y',strtotime($copy_request->created_at))); ?></td>
                                            <td><?php echo e(date('M d Y',strtotime($copy_request->date_needed))); ?></td>
                                            <td><?php echo e($copy_request->user->name); ?></td>
                                            <td><?php echo e($copy_request->status); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                            <div class="tab-pane" id="tab-4">
                                <table class="table table-striped tables">
                                    <thead>
                                        <tr>
                                            <th>Memo #</th>
                                            <th>Title</th>
                                            <th>Status</th>
                                            <th>Attachment</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $document->memo_document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memo_docs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($memo_docs->memorandum->memo_number); ?></td>
                                                <td><?php echo e($memo_docs->memorandum->title); ?></td>
                                                <td>
                                                    <?php if($memo_docs->memorandum->status == 'Private'): ?>
                                                        <span class="label label-danger">Private</span>
                                                    <?php else: ?>
                                                        <span class="label label-primary">Public</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(url($memo_docs->memorandum->file_memo)); ?>" target="_blank">
                                                        <i class="fa fa-file"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            </div>

                            </div>

                            </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('copy_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('change_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('obsolete_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<div class="modal" id="edit_document" tabindex="-1" role="dialog"  >
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class='col-md-10'>
                    <h5 class="modal-title" id="exampleModalLabel">Change Document</h5>
                </div>
                <div class='col-md-2'>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            <form method='post' action='edit-document/<?php echo e($document->id); ?>' onsubmit='show();'  enctype="multipart/form-data" >
                <div class="modal-body">
                    <?php echo e(csrf_field()); ?>

                    <div class='row'>
                        <div class='col-md-12'>
                           Title :
                            <input type="text" class="form-control-sm form-control "  value='<?php echo e($document->title); ?>' name="title" required/>
                        </div>
                        <div class='col-md-12'>
                            Revision # :
                            <input type="text" class="form-control-sm form-control "  value='<?php echo e($document->version); ?>'  name="revision" required/>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type='submit'  class="btn btn-primary" >Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('obsolete_request_image', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script type="text/javascript">
    $(window).on('load', function() {
        $('#myModal').modal('show');
    });
</script>
<script>
    $(document).ready(function(){
        

        $('.cat').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            bPaginate: false,
            bInfo : false,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                {extend: 'pdf', title: 'Histories'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>