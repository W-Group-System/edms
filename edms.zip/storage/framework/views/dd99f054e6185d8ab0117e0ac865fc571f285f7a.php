
<div class="modal" id="edit_title<?php echo e($request->id); ?>" tabindex="-1" role="dialog"  >
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class='col-md-10'>
                    <h5 class="modal-title" id="exampleModalLabel">Change Title</h5>
                </div>
                <div class='col-md-2'>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            <form method='post' action='edit-title/<?php echo e($request->id); ?>' onsubmit='show();'  enctype="multipart/form-data" >
                <div class="modal-body">
                    <?php echo e(csrf_field()); ?>

                    <div class='row'>
                        <div class='col-md-12'>
                           Title :
                            <input type="text" class="form-control-sm form-control "  value='<?php echo e($request->title); ?>' name="title" required/>
                        </div>
                        
                            <div class='col-md-12'>
                            Document Type :
                            <select name='document_type' class='form-control-sm form-control cat' required>
                                <option value=""></option>
                                <?php $__currentLoopData = $document_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='<?php echo e($types->name); ?>' <?php if($request->type_of_document == $types->name): ?> selected <?php endif; ?>><?php echo e($types->code); ?> - <?php echo e($types->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                        
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type='submit'  class="btn btn-primary" >Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>