<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('login_css/css/plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Users</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($users)); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Active</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($users->where('status',""))); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Deactivated</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($users->where('status','1'))); ?></h1>
                </div>
            </div>
        </div>
        
    </div>
    <div class='row'>
        <div class="col-lg-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Approved Account Requests</h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Company</th>
                                <th>Department</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users->where('status', 'New Account' ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approved_requests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($approved_requests->name); ?></td>
                                <td><?php echo e($approved_requests->email); ?></td>
                                <td><?php echo e($approved_requests->company->name); ?></td>
                                <td><?php echo e(optional($approved_requests->department)->name); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info"  title='Edit' data-target="#editNewUserAccount<?php echo e($approved_requests->id); ?>" data-toggle="modal"><i class="fa fa-edit"></i></button>
                                </td>
                            </tr>
                            <?php echo $__env->make('edit_new_account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Users <button class="btn btn-success "  data-target="#new_account" data-toggle="modal" type="button"><i class="fa fa-plus"></i>&nbsp;New Account</button></h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Company</th>
                                <th>Department</th>
                                
                                <th>Share Department</th>
                                <th>Role</th>
                                
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users->where('status',"!=","New Account"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->company->name); ?></td>
                                <td><?php echo e(optional($user->department)->name); ?></td>
                                
                                <td>
                                    <small>
                                    <?php $__currentLoopData = $user->departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($department->dep->name); ?>  <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </small>
                                </td>
                                <td><?php echo e($user->role); ?></td>
                                <td  id='statususer<?php echo e($user->id); ?>'><?php if($user->status): ?> <small class="label label-danger">Inactive</small>  <?php else: ?> <small class="label label-primary">Active</small> <?php endif; ?></td>
                                <td data-id='<?php echo e($user->id); ?>' id='actionuser<?php echo e($user->id); ?>'>

                                        <?php if($user->status): ?>
                                            <button class="btn btn-sm btn-primary activate-user" id='<?php echo e($user->id); ?>' title="Activate"><i class="fa fa-check"></i></button>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-warning" data-target="#change_pass<?php echo e($user->id); ?>" data-toggle="modal" title='change password' ><i class="fa fa-key"></i></button>
                                            <button class="btn btn-sm btn-info"  title='Edit' data-target="#editUser<?php echo e($user->id); ?>" data-toggle="modal"><i class="fa fa-edit"></i></button>
                                        <?php if(Auth::user()->id != $user->id): ?>
                                            <button class="btn btn-sm btn-danger deactivate-user" id='<?php echo e($user->id); ?>' title='Deactivate' ><i class="fa fa-trash"></i></button><?php endif; ?>
                                        <?php endif; ?>
                                </td>
                            </tr>
                            <?php echo $__env->make('edit_user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                            <?php echo $__env->make('changepassword', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>
<?php echo $__env->make('new_account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/sweetalert/sweetalert.min.js')); ?>"></script>

<script>
    $(document).ready(function(){
        $('.deactivate-user').click(function () {
        
        var id = this.id;
            swal({
                title: "Are you sure?",
                text: "This user will be deactivated!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, deactivated it!",
                closeOnConfirm: false
            }, function (){
                $.ajax({
                    dataType: 'json',
                    type:'POST',
                    url:  '<?php echo e(url("deactivate-user")); ?>',
                    data:{id:id},
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                }).done(function(data){
                    console.log(data);
                    swal("Deactivated!", "User is now deactivated.", "success");
                    location.reload();
                }).fail(function(data)
                {
                    
                    swal("Deactivated!", "User is now deactivated.", "success");
                location.reload();
                });
            });
        });
        $('.activate-user').click(function () {
        
        var id = this.id;
            swal({
                title: "Are you sure?",
                text: "This user will be activated!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, Activated it!",
                closeOnConfirm: false
            }, function (){
                $.ajax({
                    dataType: 'json',
                    type:'POST',
                    url:  '<?php echo e(url("activate-user")); ?>',
                    data:{id:id},
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                }).done(function(data){
                    console.log(data);
                    swal("Activated!", "User is now activated.", "success");
                    location.reload();
                }).fail(function(data)
                {
                    
                    swal("Activated!", "User is now activated.", "success");
                location.reload();
                });
            });
        });
        
        $('.cat').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            stateSave: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>