<div class="modal" id="edit<?php echo e($department->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit DCO</h5>
            </div>
            <form method="POST" action="<?php echo e(url('edit_dco/'.$department->id)); ?>" onsubmit="show()">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class='row'>
                        <div class='col-md-12'>
                            Dco :
                            
                            <select name='dco[]' class='form-control-sm form-control cat' multiple required>
                                <option value=""></option>
                                <?php
                                    $dco_array = $department->dco->pluck('user_id')->toArray();
                                ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php if(in_array($user->id, $dco_array)): ?> selected <?php endif; ?>><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>