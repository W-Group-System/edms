<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <div class='row'>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Audit Logs </h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                        <thead>
                                <tr>
                                    
                                    <th>Created Date</th>
                                    <th>Model</th>
                                    <th>User</th>
                                    <th>Event</th>
                                    <th>Auditable Id</th>
                                    <th>Old Values</th>
                                    <th>New Values</th>
                                    <th>Ip Address</th>
                                    <th>Agent</th>
                                </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $audits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <td><?php echo e(date('Y-m-d h:i:s',strtotime($audit->created_at))); ?></td>
                                    <td><?php echo e($audit->auditable_type); ?></td>
                                    <td><?php if($audit->user): ?><?php echo e($audit->user->name); ?><?php endif; ?></td>
                                    <td><?php echo e($audit->event); ?></td>
                                    <td><?php echo e($audit->auditable_id); ?></td>
                                    <td title='<?php echo e($audit->old_values); ?>'><?php echo e(substr($audit->old_values,0,10)); ?></td>
                                    <td title='<?php echo e($audit->new_values); ?>'><?php echo e(substr($audit->new_values,0,10)); ?></td>
                                    <td><?php echo e($audit->ip_address); ?></td>
                                    <td><?php echo e($audit->user_agent); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script>
    $(document).ready(function(){
        

        $('.locations').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 10,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>