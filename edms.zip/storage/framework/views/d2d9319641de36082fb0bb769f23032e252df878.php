<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <div class="row">
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>For Upload</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><a href='<?php echo e(url("acknowledgement")); ?>'><?php echo e(count($requests->where('acknowledgement',null))); ?></a></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Uploaded</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><a href='<?php echo e(url("uploaded-acknowledgement")); ?>'><?php echo e(count($requests->where('acknowledgement','!=',null))); ?></a></h1>
                </div>
            </div>
        </div>
    </div>
    <div class='row'>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Uploaded </h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                            <thead>
                                <tr>
                                    
                                    <th>Actions</th>
                                    <th>Reference No.</th>
                                    <th>Request Type</th>
                                    <th>Date Requested</th>
                                    <th>Code</th>
                                    <th>Title</th>
                                    <th>Date Cascade</th>
                                    <th>Type</th>
                                    <th>Requested By</th>
                                    <th>Date Uploaded</th>
                                    <th>Status</th>
                                    <th>Acknowledged By</th>
                                </tr>
                            </thead>
                        <tbody>
                            <?php $__currentLoopData = $requests->where('acknowledgement','!=',null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td>
                                            <a href="#"  data-target="#view_request<?php echo e($request->id); ?>" data-toggle="modal" class='btn btn-sm btn-info'><i class="fa fa-eye"></i></a>
                                            <a href="#" data-target="#view_upload<?php echo e($request->id); ?>" data-toggle="modal" class='btn btn-sm btn-danger'><i class="fa fa-wrench"></i></a>
                                        </td>
                                        <td>DICR-<?php echo e(str_pad($request->id, 5, '0', STR_PAD_LEFT)); ?></td>
                                        <td><?php echo e($request->request_type); ?></td>
                                        <td><?php echo e(date('M d Y',strtotime($request->created_at))); ?></td>
                                     
                                            <?php if($request->document_id != null): ?>
                                            <td>
                                                <?php echo e($request->control_code); ?>

                                            </td>   
                                            <td>
                                                <?php echo e($request->title); ?>

                                            </td>   
                                            <td>
                                                <?php echo e(date('Y-m-d',strtotime($request->updated_at))); ?>

                                            </td>   
                                           
                                            <?php else: ?>
                                            <td></td>
                                            <td><?php echo e($request->title); ?></td>
                                            <td></td>
                                            <?php endif; ?>
                                            <td>
                                                <?php echo e($request->type_of_document); ?>

                                            </td>   
                                        <td><?php echo e($request->user->name); ?></td>
                                        <td><?php echo e(date('M d Y', strtotime($request->acknowledgement->created_at))); ?></td>
                                        <td> <?php if($request->status == "Pending"): ?>
                                            <span class='label label-warning'>
                                        <?php elseif($request->status ==  "Approved"): ?>
                                            <span class='label label-info'>    
                                        <?php elseif($request->status ==  "Declined"): ?>
                                                <span class='label label-danger'>
                                        <?php else: ?><span class='label label-success'>
                                            <?php endif; ?>
                                            <?php echo e($request->status); ?></span>  </td>
                                        <td><?php echo e($request->acknowledgement->user->name); ?></td>
                                    </tr>
                                    <?php echo $__env->make('view_change_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <?php echo $__env->make('view_upload', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script>
    $(document).ready(function(){
        

        $('.locations').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            sorting:false,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>