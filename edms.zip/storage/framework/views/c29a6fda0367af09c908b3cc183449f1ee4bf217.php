<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('login_css/css/plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content animated fadeInRight">

    
    <div class="row">

        
        <div class="col-lg-3">
            <div class="ibox">
                <div class="ibox-title">
                    <h5>For Approval</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins">
                        <?php echo e($memos->where('final_status', 'Pending')->count()); ?>

                    </h1>
                </div>
            </div>
        </div>

        
        <div class="col-lg-3">
            <div class="ibox">
                <div class="ibox-title">
                    <h5>Declined</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins">
                        <?php echo e($memos->where('final_status', 'Declined')->count()); ?>

                    </h1>
                </div>
            </div>
        </div>

    </div>
    


    
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <!-- Header -->
                <div class="ibox-title">
                    <h5>For Approval Memorandum</h5>
                    
                    
                    <div class="ibox-tools">
                        <form method="GET" action="" id="filterForm" style="display: inline-block; width: 150px;">
                            <select name="status_filter" id="status_filter" class="form-control input-sm" onchange="this.form.submit()">
                                <option value="">All Status</option>
                                <option value="Pending" <?php echo e(request('status_filter') == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="Declined" <?php echo e(request('status_filter') == 'Declined' ? 'selected' : ''); ?>>Declined</option>
                            </select>
                        </form>
                    </div>
                    

                </div>
                
                <!-- Content -->
                <div class="ibox-content">
                    <div class="table table-responsive">
                        <table class="table table-striped table-bordered table-hover tables">
                            <thead>
                                <tr>
                                    <th>Action</th>
                                    <th>Department</th>
                                    <th>Memo Number</th>
                                    <th>Title</th>
                                    <th>Released Date</th>
                                    <th>Uploaded By</th>
                                    <th>Align Policy</th>
                                    <th>Attachment</th>
                                    <th>Remarks</th>
                                    <th>Status</th>
                                </tr>
                            </thead>

                            <tbody>
                               <?php $__currentLoopData = $memos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                
                                <?php if(request('status_filter')): ?>
                                    <?php
                                        if ($memo->final_status != request('status_filter')) {
                                            continue;
                                        }
                                    ?>
                                <?php endif; ?>

                                <tr>
                                    <td>
                                        <?php if(empty($memo->final_status) || $memo->final_status == 'Pending' || $memo->final_status == 'For approval'): ?>
                                            <button type="button"
                                                class="btn btn-sm btn-primary"
                                                title="Approved"
                                                data-toggle="modal"
                                                data-target="#approved<?php echo e($memo->id); ?>">
                                                <i class="fa fa-check"></i>
                                            </button>
                                        <?php else: ?>
                                            <span class="text-muted" style="font-size: 11px; font-style: italic;">Processed</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?php echo e($memo->department->name ?? 'N/A'); ?>

                                    </td>

                                    <td>
                                        <?php echo e($memo->memo_number); ?>

                                    </td>

                                    <td>
                                        <?php echo e($memo->title); ?>

                                    </td>

                                    <td>
                                        <?php echo e(date('M d Y', strtotime($memo->released_date))); ?>

                                    </td>

                                    <td>
                                        <?php echo e($memo->user->name ?? 'N/A'); ?>

                                    </td>

                                    <td>
                                        <?php $__currentLoopData = $memo->memorandum_document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memo_docs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(url('view-document/'.$memo_docs->document->id)); ?>">
                                                <?php echo e($memo_docs->document->control_code); ?>

                                            </a>
                                            <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>

                                    <td>
                                        <a href="<?php echo e(url($memo->file_memo)); ?>" target="_blank">
                                            <i class="fa fa-file"></i>
                                        </a>
                                    </td>

                                    <td>
                                        <?php if($memo->final_status == 'Declined'): ?>
                                            <span class="text-danger"><?php echo e($memo->remarks ?? 'N/A'); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($memo->status == 'Private' || $memo->status == 'Declined' || $memo->final_status == 'Declined'): ?>
                                            <span class="label label-danger">
                                                Declined
                                            </span>
                                        <?php else: ?>
                                            <span class="label label-primary">
                                                <?php echo e($memo->final_status ?? 'Pending'); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    

                                </tr>
                                
                                
                                <?php echo $__env->make('approved_memorandum', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/sweetalert/sweetalert.min.js')); ?>"></script>

<script>
$(document).ready(function() {
    $('.tables').DataTable({
        pageLength: 25,
        responsive: true,
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
            { extend: 'copy' },
            { extend: 'csv' },
            { extend: 'excel', title: 'For Approval Memorandum' },
            { extend: 'pdf', title: 'For Approval Memorandum' },
            { 
                extend: 'print',
                customize: function(win) {
                    $(win.document.body).addClass('white-bg').css('font-size', '10px');
                    $(win.document.body).find('table').addClass('compact').css('font-size', 'inherit');
                }
            }
        ]
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>