<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('login_css/css/plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Documents</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($documents->where('status',null))); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>New Documents this <?php echo e(date('M Y')); ?></h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($documents->whereBetween('created_at',[date('Y-m-01'), date('Y-m-t')]))); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Revised this <?php echo e(date('M Y')); ?></h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($documents->whereBetween('updated_at',[date('Y-m-01'), date('Y-m-t')]))); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Obsolete</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($obsoletes)+count($documents->where('status',"Obsolete"))); ?></h1>
                </div>
            </div>
        </div>
    </div>
    <div class='row'>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Documents
                        <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Business Process Manager') || (auth()->user()->role == 'Management Representative') ||(auth()->user()->role == 'Document Control Officer') ): ?>
                        <button class="btn btn-success "  data-target="#uploadDocument" data-toggle="modal" type="button"><i class="fa fa-plus"></i>&nbsp;Upload Document</button></h5>
                        <?php endif; ?>
                    </div>
                <div class="ibox-content">
                    <form method="GET" action="" class="custom_form" enctype="multipart/form-data">
                        <div class="row">
                            
                            <div class="col-md-2">
                                <select class='form-control cat' name='department' placeholder="Department" >
                                        <option value=''>Select All Department</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value='<?php echo e($department->id); ?>' <?php echo e(($department->id == $dep) ? 'selected="selected"' : ''); ?>  ><?php echo e($department->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                               
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-primary btn-md btn-submit" style="width:100px;border-radius:4px" type="submit">Search</button>
                            </div>
                        </div>
                    </form>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                        <thead>
                            <tr>
                                <th>Action</th>
                               
                                <th>Control Code</th>
                                <th>Old Code</th>
                                <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Business Process Manager') || (auth()->user()->role == 'Management Representative') || (auth()->user()->role == "Document Control Officer")): ?>
                                <th>Public</th>
                                <?php endif; ?>
                                <th>Revisions</th>
                                <th>Company</th>
                                <th>Department</th>
                                <th>Document</th>
                                <th>Type of Document</th>
                                <th>Effective Date</th>
                                <th>Process Owner</th>
                                <th>Uploaded By</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $documents_na; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(url('view-document/'.$document->id)); ?>" target="_blank" class='btn btn-sm btn-info'><i class="fa fa-eye"></i></a></td>
                                    <td><?php echo e($document->control_code); ?></td>
                                    <td><?php echo e($document->old_control_code); ?></td>
                                    <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Business Process Manager') || (auth()->user()->role == 'Management Representative') || (auth()->user()->role == "Document Control Officer")): ?>
                                        <td><input class='form-control form-control-sm' type='checkbox' name='public' onchange='public_info(this,<?php echo e($document->id); ?>)' <?php if($document->public != null): ?> checked <?php endif; ?>><i></i> </td>
                                    <?php endif; ?>
                                    <td><?php echo e($document->version); ?></td>
                                    <td><?php echo e($document->company->name); ?></td>
                                    <td><?php echo e($document->department->name); ?></td>
                                    <td><?php echo e($document->title); ?></td>
                                    <td><?php echo e($document->category); ?></td>
                                    <td><?php echo e(date('M d, Y',strtotime($document->updated_at))); ?></td>
                                    
                                    <td>
                                        <?php if($document->process_owner != null): ?>
                                            <small class="label label-info"><?php echo e($document->processOwner->name); ?></small>
                                        <?php else: ?> 
                                            
                                            <small class="label label-info"><?php echo e($document->department->dep_head->name); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($document->user->name); ?></td>
                                    <td><?php if($document->status == null): ?><span class="label label-primary">Active</span> <?php else: ?><span class="label label-danger">Obsolete</span> <?php endif; ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                        
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>
<?php echo $__env->make('upload_document', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>

<script src="<?php echo e(asset('login_css/js/plugins/sweetalert/sweetalert.min.js')); ?>"></script>
<script>

    function public_info(value,id)
    {
        console.log(value.checked);

     
                $.ajax({
                    dataType: 'json',
                    type:'POST',
                    url:  '<?php echo e(url("/change-public")); ?>',
                    data:{id:id,value:value.checked},
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                }).done(function(data){
                    console.log(data);
                }).fail(function(data)
                {
                
                });
    }
    $(document).ready(function(){
        

        $('.cat').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>