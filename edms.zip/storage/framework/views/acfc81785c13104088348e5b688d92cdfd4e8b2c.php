<div class="modal prr-scrollable-modal edit-prr-modal" id="editRequest<?php echo e($request->id); ?>" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="col-md-10">
                    <h5 class="modal-title">
                        Edit Quality Process Review Request Details
                    </h5>
                </div>
                <div class="col-md-2">
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            <form action="<?php echo e(route('process-review.update', $request->id)); ?>"
                method="POST"
                onsubmit="show();"
                class="form-horizontal"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="row">
                        
                        <div class="col-md-6">
                            Request Type :
                            <select name="type_of_request" class="form-control-sm form-control edit-type-of-request" required>
                                <option value="" <?php echo e(old('type_of_request', $request->type_of_request) == '' ? 'selected' : ''); ?>>
                                    Select Options
                                </option>
                                <option value="New" <?php echo e(old('type_of_request', $request->type_of_request) == 'New' ? 'selected' : ''); ?>>
                                    New
                                </option>
                                <option value="Revision" <?php echo e(old('type_of_request', $request->type_of_request) == 'Revision' ? 'selected' : ''); ?>>
                                    Revision
                                </option>
                            </select>
                        </div>

                        
                        <div class="col-md-6">
                            Reason for Request :
                            <select name="reason_for_new_request" class="form-control" required>
                                <option value="" <?php echo e(old('reason_for_new_request', $request->reason_of_request) == '' ? 'selected' : ''); ?>>
                                    Select an option
                                </option>
                                <option value="Updated Regulations or Standards" <?php echo e(old('reason_for_new_request', $request->reason_of_request) == 'Updated Regulations or Standards' ? 'selected' : ''); ?>>
                                    Updated Regulations or Standards (Legal Compliance and ISO standards)
                                </option>
                                <option value="Process Improvement" <?php echo e(old('reason_for_new_request', $request->reason_of_request) == 'Process Improvement' ? 'selected' : ''); ?>>
                                    Process Improvement (Technological Advancements & Operational Processes)
                                </option>
                                <option value="Nonconformities" <?php echo e(old('reason_for_new_request', $request->reason_of_request) == 'Nonconformities' ? 'selected' : ''); ?>>
                                    Nonconformities (External and Internal Findings)
                                </option>
                                <option value="Document Modification" <?php echo e(old('reason_for_new_request', $request->reason_of_request) == 'Document Modification' ? 'selected' : ''); ?>>
                                    Document Modification (error correction, change in scope and objective, revision and new forms, minimal modifications such as adding columns, changes in formats, etc.)
                                </option>
                                <option value="Top Management Directive" <?php echo e(old('reason_for_new_request', $request->reason_of_request) == 'Top Management Directive' ? 'selected' : ''); ?>>
                                    Top Management Directive
                                </option>
                            </select>
                        </div>
                    </div>

                    <div class="edit-revision-document-list m-t-md" style="<?php echo e(old('type_of_request', $request->type_of_request) === 'Revision' ? '' : 'display: none;'); ?>">
                        <h4>Select the document to revise</h4>
                        <input type="search"
                            class="form-control edit-revision-document-search"
                            placeholder="Search documents..."
                            aria-label="Search documents to revise">
                        <div style="max-height: 300px; overflow-y: auto; padding: 0 10px;">
                            <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <label class="search-result edit-revision-document-option" style="display: block; cursor: pointer;">
                                    <input type="radio"
                                        name="document_id"
                                        value="<?php echo e($document->id); ?>"
                                        data-title="<?php echo e($document->title); ?>"
                                        data-control-code="<?php echo e($document->control_code); ?>"
                                        data-category="<?php echo e($document->category); ?>"
                                        <?php echo e(old('document_id', $request->document_id) == $document->id ? 'checked' : ''); ?>>
                                    <strong>
                                        <i>(<?php echo e($document->old_control_code); ?>)</i>
                                        <?php echo e($document->control_code); ?> Rev. <?php echo e($document->version); ?>

                                    </strong>
                                    <?php if($document->public == null): ?>
                                        <span class="label label-danger">Private</span>
                                    <?php else: ?>
                                        <span class="label label-primary">Public</span>
                                    <?php endif; ?>
                                    <br>
                                    Title : <?php echo e($document->title); ?><br>
                                    Process Owner :
                                    <?php if($document->processOwner): ?>
                                        <span class="label label-info"><?php echo e($document->processOwner->name); ?></span>
                                    <?php elseif($document->department && $document->department->dep_head): ?>
                                        <span class="label label-info"><?php echo e($document->department->dep_head->name); ?></span>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                    <p>
                                        Date Effective : <?php echo e($document->updated_at ? $document->updated_at->format('M d, Y') : 'N/A'); ?><br>
                                        Company : <?php echo e($document->department->name ?? 'N/A'); ?>

                                    </p>
                                </label>
                                <div class="hr-line-dashed"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>No active documents are available for revision.</p>
                            <?php endif; ?>
                            <p class="edit-revision-document-no-results" style="display: none;">No documents match your search.</p>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-md-12 m-t-md">
                            Title :
                            <input type="text" class="form-control-sm form-control"
                                value="<?php echo e(old('title', $request->document_title)); ?>" name="title" required/>
                        </div>
                    </div>
                    <div class="row edit-revision-control-code-row" style="<?php echo e(old('type_of_request', $request->type_of_request) === 'Revision' ? '' : 'display: none;'); ?>">
                        <div class="col-md-12 m-t-md">
                            Control Code :
                            <input type="text" name="control_code" class="form-control-sm form-control edit-revision-control-code"
                                value="<?php echo e(old('control_code', $request->control_code)); ?>" readonly
                                <?php echo e(old('type_of_request', $request->type_of_request) === 'Revision' ? 'required' : ''); ?>/>
                        </div>
                    </div>

                    <div class="row">
                        
                        <div class="col-md-4 m-t-md">
                            Company :
                            <select name="company" class="form-control-sm form-control cat" required>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()->company_id == $company->id): ?>
                                        <option value="<?php echo e($company->id); ?>" <?php echo e(old('company', $request->company_id) == $company->id ? 'selected' : ''); ?>>
                                            <?php echo e($company->code); ?> <?php echo e($company->name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div class="col-md-4 m-t-md">
                            Department :
                            <select name="department" class="form-control-sm form-control cat" required>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()->department_id == $dep->id): ?>
                                        <option value="<?php echo e($dep->id); ?>" <?php echo e(old('department', $request->department_id) == $dep->id ? 'selected' : ''); ?>>
                                            <?php echo e($dep->code); ?> <?php echo e($dep->name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div class="col-md-4 m-t-md">
                            Document Type :
                            <select name="category" class="form-control-sm form-control" required>
                                <option value="">Select an option</option>
                                <?php $__currentLoopData = $document_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->name); ?>" <?php echo e(old('category', $request->type_of_document) == $type->name ? 'selected' : ''); ?>>
                                        <?php echo e($type->code); ?> <?php echo e($type->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row m-t-md">
                        
                        
                        
                        <div class="col-md-6">
                            Supporting Document <small><i>(PSF,Executive Summary,Etc.)</i></small> :
                            <input type="file" class="form-control-sm form-control" accept="application/pdf" name="supporting_document"/>
                        </div>
                    </div>

                    
                    <div class="row m-t-md">
                        <div class="col-md-12">
                            Description:
                            <textarea name="description" rows="5" class="form-control-sm form-control" required><?php echo e(old('description', $request->document_description)); ?></textarea>
                        </div>
                    </div>

                    <div class="row m-t-md">
                        <div class="col-md-12">
                            <b>Requestor : <?php echo e(auth()->user()->name); ?></b>
                        </div>
                    </div>
                    <div class="panel panel-primary m-t-md">
                        <div class="panel-heading">Revision and DCO Information</div>
                        <div class="panel-body">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="active" role="presentation">
                                    <a href="#edit-prr-dco-<?php echo e($request->id); ?>" aria-controls="edit-prr-dco-<?php echo e($request->id); ?>" role="tab" data-toggle="tab">
                                        DCO
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#edit-prr-revision-list-<?php echo e($request->id); ?>" aria-controls="edit-prr-revision-list-<?php echo e($request->id); ?>" role="tab" data-toggle="tab">
                                        Revision List
                                    </a>
                                </li>
                            </ul>
                            <div class="tab-content m-t-md">
                                <div class="tab-pane active" id="edit-prr-dco-<?php echo e($request->id); ?>" role="tabpanel">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>DCO</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $department_dco; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($key + 1); ?></td>
                                                        <td><?php echo e($dco->user->name); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="tab-pane" id="edit-prr-revision-list-<?php echo e($request->id); ?>" role="tabpanel">
                                    <div class="edit-selected-document-change-requests">
                                        <h4>Revision List/s</h4>
                                        <p class="edit-no-document-selected" style="<?php echo e(old('document_id', $request->document_id) ? 'display: none;' : ''); ?>">
                                            Select a document to view its revision requests.
                                        </p>
                                        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="edit-selected-document-change-request"
                                                data-document-id="<?php echo e($document->id); ?>"
                                                style="<?php echo e(old('document_id', $request->document_id) == $document->id ? '' : 'display: none;'); ?>">
                                                <div class="table-responsive">
                                                    <table class="table table-striped revisionTables">
                                                        <thead>
                                                            <tr>
                                                                <th>Control Code</th>
                                                                <th>Title</th>
                                                                <th>Type of Request</th>
                                                                <th>Requested Date</th>
                                                                <th>Requestor</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                                $documentChangeRequests = $changeRequests->where('control_code', $document->control_code);
                                                            ?>
                                                            <?php $__currentLoopData = $documentChangeRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $changeRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($changeRequest->control_code); ?></td>
                                                                    <td><?php echo e($changeRequest->title ?? 'N/A'); ?></td>
                                                                    <td><?php echo e($changeRequest->request_type ?? 'N/A'); ?></td>
                                                                    <td><?php echo e($changeRequest->created_at ? $changeRequest->created_at->format('M d, Y') : 'N/A'); ?></td>
                                                                    <td><?php echo e(optional($changeRequest->user)->name ?? 'N/A'); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="submission_action" value="draft" class="btn btn-secondary">Save as Draft</button>
                    <button type="submit" name="submission_action" value="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>