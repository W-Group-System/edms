
<div class="modal" id="view_request_change<?php echo e($request->id); ?>" tabindex="-1" role="dialog"  >
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class='col-md-10'>
                    <h5 class="modal-title" id="exampleModalLabel">Change Request (<?php echo e($request->status); ?>) - <b class='label label-danger'><?php echo e($request->request_type); ?></b></h5>
                </div>
                <div class='col-md-2'>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            <form method='post' action='<?php echo e(url('change-request-action/'.$change_approval->id)); ?>' onsubmit='show();' class="form-horizontal"  enctype="multipart/form-data" >
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="department" value="<?php echo e($request->department_id); ?>">
                
                <div class="modal-body">
                    <div class='row '>
                        <div class='col-md-6'>
                            Reference Number : <b>DICR-<?php echo e(str_pad($request->id, 5, '0', STR_PAD_LEFT)); ?></b>
                        </div>
                        <div class='col-md-6'>
                            Type of Document : <?php echo e($request->type_of_document); ?>

                        </div>
                        <div class='col-md-6'>
                            
                        </div>
                        
                        <div class='col-md-6'>
                            <?php if($request->request_type != "Obsolete"): ?>
                            Draft Link : <a href='<?php echo e($request->link_draft); ?>' target="_blank">Draft Link</a> <br>
                            <?php endif; ?>
                            <?php if($request->original_attachment_pdf != null): ?>
                            Original PDF Link : <a href='<?php echo e(url($request->original_attachment_pdf)); ?>' target="_blank">Link</a> <br>
                            <?php endif; ?>
                            
                            
                            <?php if($request->supporting_documents != null): ?>
                            Supporting Documents : <a href="<?php echo e(url($request->supporting_documents)); ?>" target="_blank">Link</a> <br>
                            <?php endif; ?>

                        </div>
                    </div>
                    <hr>
                    <div class='row '>
                        <?php if($request->request_type != "New"): ?>
                        <div class='col-md-6'>
                            Control Code : <?php echo e($request->control_code); ?> Rev. <?php echo e($request->revision); ?>

                        </div>
                        <?php endif; ?>
                        <div class='col-md-6'>
                            Title : <?php echo e($request->title); ?>

                        </div>
                    </div>
                    <div class='row '>
                        <div class='col-md-6'>
                            Requested By : <?php echo e($request->user->name); ?> 
                        </div>
                        <div class='col-md-6'>
                            Date Requested : <?php echo e(date('M d, Y',strtotime($request->created_at))); ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            Reason for changes : <b><?php echo e($request->reason_for_changes); ?></b>
                        </div>
                    </div>
                    <hr>
                    <div class='row'>
                        <div class='col-md-12 '>
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <?php if($request->request_type != "Revision"): ?>
                                        Descriptions/Remarks
                                    <?php else: ?>
                                    Reason/s for Change
                                    <?php endif; ?>
                                </div>
                                <div class="panel-body">
                                   <?php echo nl2br(e($request->change_request)); ?>

                                </div>
                            </div>
                            
                            
                        </div>
                    </div>
                    <?php if($request->request_type == "Revision"): ?>
                    <div class='row '>
                        <div class='col-md-6 '>
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    From (Indicate clause)
                                </div>
                                <div class="panel-body">
                                    <?php echo nl2br(e($request->indicate_clause)); ?>

                                </div>
                            </div>
                        </div>
                        <div class='col-md-6'>
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    To (Indicate the changes)
                                </div>
                                <div class="panel-body">
                                    <?php echo nl2br(e($request->indicate_changes)); ?>

                                </div>
                            </div>
                           
                            
                        </div>
                    </div>
                    <?php endif; ?>
                    <hr>
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Approvers
                        </div>
                        <div class="panel-body">
                            <div class='row'>
                                <div class='col-md-3  border border-primary border-top-bottom border-left-right'>
                                    Name
                                </div>
                                <div class='col-md-3  border border-primary border-top-bottom border-left-right'>
                                    Status
                                </div>
                                <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                    Start Date
                                </div>
                                <div class='col-md-2  border border-primary border-top-bottom border-left-right'>
                                   Action Date
                                </div>
                                <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                    Remarks
                                </div>
                            </div>
                            <?php $__currentLoopData = $request->approvers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        
                                        <div class='row'>
                                            <div class='col-md-3 border border-primary border-top-bottom border-left-right'>
                                                <?php echo e($approver->user->name); ?>

                                            </div>
                                            <div class='col-md-3 border border-primary border-top-bottom border-left-right'>
                                                <?php echo e($approver->status); ?>

                                            </div>
                                            <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                                <?php if($approver->start_date != null): ?><?php echo e($approver->start_date); ?><?php endif; ?> &nbsp;
                                            </div>
                                            <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                                
                                                <?php if($approver->status != "Waiting" && $approver->status != "Pending"): ?>
                                                    <?php echo e(date('Y-m-d',strtotime($approver->updated_at))); ?>

                                                <?php endif; ?>
                                            </div>
                                            <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                                <?php echo nl2br(e($approver->remarks)); ?>&nbsp;
                                            </div>
                                        </div>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <hr>
                
                    <div class='row'>
                        <?php if($request->soft_copy != null): ?>
                        <div class='col-md-4'>
                            SOFT Copy : <a href='<?php echo e(url($request->soft_copy)); ?>' target="_blank" ><i class="fa fa-file-word-o"></i> Editable Copy</a>
                        </div>
                        <?php endif; ?>
                        <?php if($request->pdf_copy != null): ?>
                        <div class='col-md-4'>
                            PDF/Scanned Copy : <a href='<?php echo e(url($request->pdf_copy)); ?>' target="_blank" ><i class="fa fa-file-pdf-o"></i> PDF Copy</a>
                        </div>
                        <?php endif; ?>
                        <?php if($request->fillable_copy != null): ?>
                        <div class='col-md-4'>
                            FILLABLE Copy : <a href='<?php echo e(url($request->fillable_copy)); ?>' target="_blank" ><i class="fa fa-file-pdf-o"></i> Fillable Copy</a>
                        </div>
                        <?php endif; ?>
                    </div>
                    <hr>
                    <?php if((auth()->user()->role == "Document Control Officer") && ($request->request_type != "Obsolete")): ?>
                        <div class='row'>
                            <div class='col-md-12'>
                                <i class='text-danger'>Note : No need to protect the PDF/Scanned Copy for all document types except (Forms / Template).</i>
                            </div>
                        </div>
                        <div class='row'>
                            <div class='col-md-4'>
                                SOFT Copy <small><i>(.word,.csv,.ppt,excel,etc)</i></small>
                                <input type="file" class="form-control-sm form-control " id='soft_copy_<?php echo e($request->id); ?>'  name="soft_copy" required/>
                            </div>
                            <div class='col-md-4'>
                                FILLABLE/SCANNED Copy <small><i>(.pdf)</i></small>
                                <input type="file" class="form-control-sm form-control " id='pdf_copy_<?php echo e($request->id); ?>'  name="pdf_copy" required/>
                            </div>
                            
                            <?php if($request->type_of_document == "POLICY" || $request->type_of_document == "PROCEDURE"): ?>
                            <div class='col-md-4'>
                                Classification :
                                <select data-placeholder="Select classification" name="classification" class="form-control cat">
                                    <option value=""></option>
                                    <option value="CRITICAL">CRITICAL</option>
                                    <option value="NON-CRITICAL">NON-CRITICAL</option>
                                </select>
                            </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <div class='row'>
                        <div class='col-md-4'>
                            Action :
                            <select name='action' class='form-control-sm form-control cat'  <?php if(($request->request_type != "Obsolete")): ?>   onchange='remove_required(<?php echo e($request->id); ?>, this.value)' <?php endif; ?> required>
                                <option value=""></option>
                                <option value="Approved" >Approve</option>
                                <option value="Declined" >Decline</option>
                                <?php $__currentLoopData = $request->approvers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()->id == $approver->user_id): ?>
                                        <?php if($approver->level == "1"): ?>
                                        <?php else: ?>
                                        <option value="Returned" >Return</option>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class='col-md-8'>
                            Remarks :
                            <textarea name='remarks' class='form-control-sm form-control' required></textarea>
                        </div>
                    </div>
                    <div class='returnOptions<?php echo e($request->id); ?> row' style="display: none;">
                        <div class='col-md-4'>
                            Return To :
                            <select name='return_to' class='form-control-sm form-control cat' id="returned_to<?php echo e($request->id); ?>" >
                                
                                <option value="DocumentControlOfficer">Return to DCO</option>
                                <option value="DepartmentHead">Return to Department Head</option>
                            </select>                            
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type='submit'  class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
