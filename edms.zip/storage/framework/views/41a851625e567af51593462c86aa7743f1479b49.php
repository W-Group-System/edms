
<div class="modal" id="editNewUserAccount<?php echo e($approved_requests->id); ?>" tabindex="-1" role="dialog"  >
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class='col-md-10'>
                    <h5 class="modal-title" >Edit User</h5>
                </div>
                <div class='col-md-2'>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            
        
        <form method='post' action='edit-new-account/<?php echo e($approved_requests->id); ?>' onsubmit='show();'  enctype="multipart/form-data" >
                <div class="modal-body">
                    <?php echo e(csrf_field()); ?>

                    <div class='row'>
                        <div class='col-md-12'>
                            Name :
                            <input type="text" class="form-control-sm form-control "  value="<?php echo e($approved_requests->name); ?>"  name="name" required/>
                        </div>
                        <div class='col-md-12'>
                            Email :
                            <input type="email" class="form-control-sm form-control "  value="<?php echo e($approved_requests->email); ?>" name="email" required/>
                        </div>
                        <div class='col-md-12'>
                            Company :
                            <select name='company' class='form-control-sm form-control cat' required>
                                <option value=""></option>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='<?php echo e($company->id); ?>' <?php if($approved_requests->company_id == $company->id): ?> selected <?php endif; ?>><?php echo e($company->name); ?> - <?php echo e($company->code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class='col-md-12'>
                            Department :
                            <select name='department' class='form-control-sm form-control cat' required>
                                <option value=""></option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='<?php echo e($dep->id); ?>' <?php if($approved_requests->department_id == $dep->id): ?> selected <?php endif; ?>><?php echo e($dep->code); ?> - <?php echo e($dep->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class='col-md-12'>
                            Share Department :
                            <select name='share_department[]' class='form-control-sm form-control cat' multiple >
                                <option value=""></option>
                                <?php $__currentLoopData = $departments->where('id','!=',$approved_requests->department_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='<?php echo e($dep->id); ?>' <?php $__currentLoopData = $approved_requests->departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($d->department_id == $dep->id): ?> selected <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> ><?php echo e($dep->code); ?> - <?php echo e($dep->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class='col-md-12'>
                            Role :
                            <select name='role' class='form-control-sm form-control cat' required>
                                <option value=""></option>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <option value='<?php echo e($role); ?>' <?php if($approved_requests->role == $role): ?> selected <?php endif; ?>><?php echo e($role); ?></option>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class='col-md-12'>
                        Password:
                            <input type="password" class="form-control-sm form-control "   name="password" required/>
                        </div>
                        <div class='col-md-12'>
                            Password Confirmation:
                            <input type="password" class="form-control-sm form-control "   name="password_confirmation" required/>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type='submit'  class="btn btn-primary" >Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>