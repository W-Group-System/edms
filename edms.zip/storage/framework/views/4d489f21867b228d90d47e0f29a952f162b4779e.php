<div class="modal" id="viewWGI" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">View WGI Policies</h5>
            </div>
            <div class="modal-body">
                <ul class="list-group">
                    <?php $__currentLoopData = $company_policies->where('company_id',1)->groupBy('department_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$policies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $department = $departments->where('id', $key)->first();
                    ?>
                    <li class="list-group-item">
                        <b><?php echo e($department->name); ?> - <?php echo e(count($policies)); ?></b>
                        <button 
                            type="button"
                            class="btn btn-sm btn-primary open-policy-modal"
                            data-dismiss="modal"
                            data-toggle="modal"
                            data-target="#policiesModal<?php echo e($department->id); ?>"
                            data-return-modal="viewWGI">
                            View Policies
                        </button>

                        <hr>

                        <table class="table table-bordered">
                            <tbody>
                                <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($policy->control_code .' - '.$policy->title); ?></td>
                                    <td>
                                        <?php
                                            $change_request = ($policy->change_requests)->where('status','Approved')->sortByDesc('id')->first();
                                        ?>
                                        <?php if($change_request): ?>
                                        <span class="label label-primary"><?php echo e(date('M d Y', strtotime($change_request->updated_at))); ?></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('view_wgi_policies_nested', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>