<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <div class="row">
        <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>For Approval</h5>
                </div>
                <div class="ibox-content">
                    <h1 class="no-margins"><?php echo e(count($change_for_approvals->where('status','Pending'))); ?></h1>
                </div>
            </div>
        </div>
    </div>
    <div class='row'>
    
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Change Requests</h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                        <thead>
                        <tr>
                            <th>Actions</th>
                            <th>Reference Number</th>
                            <th>Date Requested</th>
                            <th>Document</th>
                            <th>Document Type</th>
                            <th>Requested By</th>
                            <th>Request Type</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $change_for_approvals->where('status','Pending'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $change_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $request = $change_approval->change_request;
                            ?>
                            <tr>
                                
                                <td><a href="#"  data-target="#view_request_change<?php echo e($request->id); ?>" data-toggle="modal" class='btn btn-sm btn-info'><i class="fa fa-eye"></i></a></td>
                                <td>DICR-<?php echo e(str_pad($request->id, 5, '0', STR_PAD_LEFT)); ?></td>
                                <td><?php echo e(date('M d Y',strtotime($request->created_at))); ?></td>
                                <td><small>
                                    <?php echo e($request->control_code); ?> Rev. <?php echo e($request->revision); ?><br>
                                    <?php echo e($request->title); ?> <br>
                                    <?php echo e($request->type_of_document); ?>

                                </small></td>
                                <td><?php echo e($request->type_of_document); ?></td>
                                <td><?php echo e($request->user->name); ?></td>
                                <td><?php echo e($request->request_type); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__currentLoopData = $change_for_approvals->where('status','Pending'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $change_approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$request = $change_approval->change_request;
?>
<?php echo $__env->make('view_removal_approvers', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script>
    $(document).ready(function(){
        

        $('.cat').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            sorting: false,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>