<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content">
    <div class='row'>
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <form method='GET' onsubmit='show();' enctype="multipart/form-data">
                        <div class='row'>
                            <div class="col-lg-3">
                                <div class="form-group row">
                                    <label class="col-sm-4 col-form-label text-right text-white">Select Month</label>
                                    <div class="col-sm-8">
                                        <input class='form-control-sm form-control' name='yearmonth' value='<?php echo e($search); ?>' max='<?php echo e(date('Y-m')); ?>' type='month' required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <button type="submit" class="btn btn-primary col-sm-3 col-lg-3 col-md-3">Search</button>
                            </div>
                        </div>
                    </form> 
                </div>
            </div>
        </div>
    </div> 
    <div class='row'>
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Copy Request Reports</h5>
                  
                </div>
                <div class="ibox-content">

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover tables" >
                            <thead>
                                <tr>
                                    <th>Reference No.</th>
                                    <th>Date Requested</th>
                                    <th>Control Code</th>
                                    <th>Title</th>
                                    <th>Request By</th>
                                    <th>Date needed</th>
                                    <th>Expiration Date</th>
                                    
                                    <th>Status</th>
                                    
                                    <th>Approver</th>
                                    <th>Start Date</th>
                                    <th>Action Date</th>
                                    <th>TAT</th>
                                    <th>Remarks</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                            
                                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td  rowspan='<?php echo e(count($request->approvers)); ?>'><b>CR-<?php echo e(str_pad($request->id, 5, '0', STR_PAD_LEFT)); ?></b></td>
                                    <td rowspan='<?php echo e(count($request->approvers)); ?>'><?php echo e(date('M. d, Y',strtotime($request->created_at))); ?></td>
                                    <td rowspan='<?php echo e(count($request->approvers)); ?>'><?php echo e($request->control_code); ?></td>
                                    <td rowspan='<?php echo e(count($request->approvers)); ?>'><?php echo e($request->title); ?></td>
                                    <td rowspan='<?php echo e(count($request->approvers)); ?>'><?php echo e($request->user->name); ?></td>
                                    <td rowspan='<?php echo e(count($request->approvers)); ?>'><?php echo e(date('M. d, Y',strtotime($request->date_needed))); ?></td>
                                    <td rowspan='<?php echo e(count($request->approvers)); ?>' ><?php if($request->expiration_date != null): ?><?php echo e(date('M. d, Y',strtotime($request->expiration_date))); ?><?php endif; ?></td>
                                    <td rowspan='<?php echo e(count($request->approvers)); ?>' ><?php if($request->status == "Pending"): ?>
                                        <span class='label label-warning'>
                                    <?php elseif($request->status ==  "Approved"): ?>
                                        <span class='label label-info'>    
                                    <?php elseif($request->status ==  "Declined"): ?>
                                            <span class='label label-danger'>
                                    <?php else: ?><span class='label label-success'>
                                        <?php endif; ?>
                                        <?php echo e($request->status); ?></span> </td>
                                    <?php $__currentLoopData = $request->approvers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $approver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key != 0): ?>
                                    <tr>
                                    <?php endif; ?>
                                        <td><?php echo e($approver->user->name); ?></td>
                                        <td><?php echo e($approver->start_date); ?></td>
                                        <td><?php if(($approver->status != "Waiting") && ($approver->status != "Pending")): ?><?php echo e(date('Y-m-d',strtotime($approver->updated_at))); ?><?php endif; ?></td>
                                        <td>
                                        <?php
                                            $difference =0;
                                            if($approver->status == "Pending")
                                            {
                                                $date_after = date('Y-m-d');
                                                $date_before = date('Y-m-d',strtotime($approver->start_date));
                                                $difference = strtotime($date_after)-strtotime($date_before);
                                            }
                                            else 
                                            {
                                                $date_after = date('Y-m-d',strtotime($approver->updated_at));
                                                $date_before = date('Y-m-d',strtotime($approver->start_date));
                                                $difference = strtotime($date_after)-strtotime($date_before);
                                                
                                            }
                                        ?>
                                        <?php if($approver->status != "Waiting"): ?>
                                        <?php echo e($difference/(24*60*60)); ?> day/s
                                        <?php endif; ?>
                                        </td>
                                        <td><?php if($approver->status != "Waiting"): ?><?php echo e($approver->remarks); ?><?php endif; ?></td>
                                        <td>
                                            <?php if($approver->status == "Pending"): ?>
                                                <span class='label label-warning'>
                                            <?php elseif($approver->status ==  "Approved"): ?>
                                                <span class='label label-info'>    
                                            <?php elseif($approver->status ==  "Declined"): ?>
                                                    <span class='label label-danger'>
                                            <?php else: ?><span class='label label-success'>
                                                <?php endif; ?>
                                                <?php echo e($approver->status); ?></span>  
                                        </td>
                                    </tr>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script>
    $(document).ready(function(){
        $('.tables').DataTable({
            pageLength: 25,
            responsive: true,
            sorting:false,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                { extend: 'copy'},
                {extend: 'csv'},
                {extend: 'excel', title: 'ExampleFile'},
                {extend: 'pdf', title: 'ExampleFile'},

                {extend: 'print',
                 customize: function (win){
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                }
                }
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>