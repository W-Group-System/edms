
<div class="modal" id="view_upload<?php echo e($request->id); ?>" tabindex="-1" role="dialog"  >
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class='col-md-10'>
                    <h5 class="modal-title" id="exampleModalLabel">Accomplished Form</h5>
                </div>
                <div class='col-md-2'>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            
                <div class="modal-body">
                    <?php if($request->acknowledgement->file): ?>
                        <div class='row '>
                            <div class='col-md-12'>
                            Attachment : <a href="<?php echo e(url($request->acknowledgement->file)); ?>" target='_blank'><i class="fa fa-file-text-o"></i> </a>
                            <a href="#" class="text-danger" data-target="#upload_acknowledgement<?php echo e($request->id); ?>" data-toggle="modal" data-dismiss="modal"><i class="fa fa-edit"></i></a>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class='row '>
                        <div class='col-md-12'>
                           Date Uploaded/Acknowledged : <?php echo e(date('F d, Y', strtotime($request->acknowledgement->created_at))); ?> </a>
                        </div>
                    </div>
                    <div class='row '>
                        <div class='col-md-12'>
                          Uploaded/Acknowledged By : <?php echo e($request->acknowledgement->user->name); ?> </a>
                        </div>
                    </div>
                  
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
        </div>
    </div>
</div>
<?php echo $__env->make('upload_acknowledgement', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
