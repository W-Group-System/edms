<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(URL::asset('images/icon.png')); ?>">

    <!-- Scripts -->
    
    <link href="<?php echo e(asset('login_css/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('login_css/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('login_css/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('login_css/css/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
    <style>
      
        .bold-text {
            font-weight: bold;
        }
        .shownext { display: none; }
        li:hover + .shownext { display: block; }
        .loader {
            position: fixed;
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background: url("<?php echo e(asset('login_css/img/loader.gif')); ?>") 50% 50% no-repeat white;
            opacity: .8;
            background-size: 120px 120px;
        }

        .dataTables_filter {
        float: right;
        text-align: right;
        }
        .dataTables_info {
        float: left;
        text-align: left;
        }
        textarea {
    resize: vertical;
    }
    @media (min-width: 768px) {
  .modal-xl {
    width: 90%;
   max-width:1200px;
  }
}
    </style>
    <!-- Fonts -->
    <!-- Styles -->
    
</head>
<body class='pace-done mini-navbar'>
    <div id="loader" style="display:none;" class="loader">
    </div>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation" style="margin-bottom: 0">
            <div class="sidebar-collapse">
                <ul class="nav metismenu tooltip-demo" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element"> <span>
                                <img alt="image" class="img-circle" style='width:50px;' src="<?php echo e(asset('images/no_image.png')); ?>" />
                            </span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo e(auth()->user()->name); ?></strong>
                                 </span> <span class="text-muted text-xs block"><?php echo e(auth()->user()->role); ?> <b class="caret"></b></span> </span> </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="#">Change Password</a></li>
                            </ul>
                        </div>
                        <div class="logo-element">
                            
                            <img alt="image" class="img-circle" style='width:50px;' src="<?php echo e(asset('images/no_image.png')); ?>" />
                        </div>
                        
                    </li>
                    <!-- //sidebar -->
                    <?php if((auth()->user()->role != "User")): ?>
                        <li class="<?php echo e(Route::current()->getName() == 'home' ? 'active' : ''); ?> shownext" data-toggle="tooltip" data-placement="right" title="Dashboard">
                            <a href="<?php echo e(url('/home')); ?>"><i class="fa fa-th-large"></i> <span
                                    class="nav-label " >Dashboard </span></a>
                        </li>
                    <?php endif; ?>
                    <li class="<?php echo e(Route::current()->getName() == 'search' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Search">
                        <a href="<?php echo e(url('/search')); ?>"><i class="fa fa-search"></i> <span
                                class="nav-label">Search </span></a>
                    </li>
                    <li class="<?php echo e(Route::current()->getName() == 'requests' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Copy Requests">
                        <a href="<?php echo e(url('/request')); ?>"><i class="fa fa-paper-plane"></i> <span
                                class="nav-label">Copy Requests </span></a>
                    </li>
                    <?php if((auth()->user()->role == "Administrator") || (auth()->user()->role == "Document Control Officer") || (auth()->user()->id == "286")): ?>
                    <li class="<?php echo e(Route::current()->getName() == 'pre_assessment' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Pre-Assessment">
                        <a href="<?php echo e(url('/pre_assessment')); ?>"><i class="fa fa-file"></i> <span
                                class="nav-label">Pre-assessment </span></a>
                    </li>
                    <?php endif; ?>

                    
                    <li class="<?php echo e(Route::current()->getName() == 'process-review' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Process Review">
                        <a href="<?php echo e(url('/process-review')); ?>"><i class="fa fa-list-alt"></i> <span class="nav-label">Process Review</span></a>
                    </li>
                    

                    
                    <li class="<?php echo e(Route::current()->getName() == 'change-requests' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Change Requests">
                        <a href="<?php echo e(url('/change-requests')); ?>"><i class="fa fa-edit"></i> <span
                                class="nav-label">Change Requests </span></a>
                    </li>
                    
                    <?php if((count(auth()->user()->copy_approvers) != 0) || (count(auth()->user()->department_approvers) != 0) || (count(auth()->user()->change_approvers) != 0) || auth()->user()->role == 'Administrator'): ?>
                    <li class="<?php echo e(Route::current()->getName() == 'for-approval' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="For Approval">
                        <a href="<?php echo e(url('/for-approval')); ?>"><i class="fa fa-check-square-o"></i> <span
                                class="nav-label">For Approval </span></a>
                    </li>
                    <?php endif; ?>
                    
                    <li class="<?php echo e(Route::current()->getName() == 'documents' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Documents">
                        <a href="<?php echo e(url('/documents')); ?>"><i class="fa fa-files-o"></i> <span
                                class="nav-label">Documents </span></a>
                    </li>
                    <li class="<?php echo e(Route::current()->getName() == 'acknowledgement' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Acknowledgement">
                        <a href="<?php echo e(url('/acknowledgement')); ?>"><i class="fa fa-vcard"></i> <span
                                class="nav-label">Acknowledgement </span></a>
                    </li>
                    
                    <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Document Control Officer') || (auth()->user()->role == 'Business Process Manager') || (auth()->user()->role == 'Management Representative') || (auth()->user()->role == 'Department Head') ||  (count(auth()->user()->accountable_persons) !=0 )): ?>
                    <li class="<?php echo e(Route::current()->getName() == 'permits' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Permits & Licenses">
                        <a href="<?php echo e(url('/permits')); ?>"><i class="fa fa-file-archive-o"></i> <span
                                class="nav-label">Permits & Licenses </span></a>
                    </li>
                    <?php endif; ?>
                    <?php if(auth()->user()->audit_role != null): ?>
                    <li class="<?php echo e(Route::current()->getName() == 'audit' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Audit">
                        <a href="<?php echo e(url('/audits')); ?>"><i class="fa fa-files-o"></i> <span
                                class="nav-label">Documents IA</span></a>
                    </li>
                    <?php endif; ?>
                    <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Business Process Manager') || (auth()->user()->role == 'Management Representative')): ?>
                    <li class="<?php echo e(Route::current()->getName() == 'remove-approvers' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Approvers">
                        <a href="<?php echo e(url('/remove-approvers')); ?>"><i class="fa fa-search-minus"></i> <span
                                class="nav-label">Approvers</span></a>
                    </li>
                    <li class="<?php echo e(Route::current()->getName() == 'settings' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Settings">
                        <a href="#"><i class="fa fa-gavel"></i> <span class="nav-label">Settings</span><span
                                class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li ><a href="<?php echo e(url('/companies')); ?>"></i>Companies</a></li>
                            <li><a href="<?php echo e(url('/departments')); ?>"></i>Departments</a></li>
                            <li><a href="<?php echo e(url('/users')); ?>"></i>Users</a></li>
                            <li><a href="<?php echo e(url('/dco')); ?>"></i>DCO</a></li>
                            
                        </ul>
                    </li>
                    
                    <li class="<?php echo e(Route::current()->getName() == 'reports' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Reports">
                        <a href="#"><i class="fa fa-list-ul"></i> <span class="nav-label">Reports</span><span
                                class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Management Representative')): ?>
                            <li><a href="<?php echo e(url('/logs')); ?>"></i>Logs</a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(url('/dicr-reports')); ?>"></i>Change Requests</a></li>
                            <li><a href="<?php echo e(url('/copy-reports')); ?>"></i>Copy Requests</a></li>
                            <li><a href="<?php echo e(url('/dco-reports')); ?>"></i>DCO</a></li>
                            <li><a href="<?php echo e(url('masterlist-internal-documents')); ?>">Masterlist of Internal Document</a></li>
                            <li><a href="<?php echo e(url('masterlist-external-documents')); ?>">Masterlist of External Document</a></li>
                            <li><a href="<?php echo e(url('masterlist-form-templates-documents')); ?>">Masterlist of Forms and Templates</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <?php if((auth()->user()->role == 'Administrator') || (auth()->user()->role == 'Document Control Officer') || (auth()->user()->role == 'Business Process Manager') || (auth()->user()->role == 'Department Head')): ?>
                    <li class="<?php echo e(Route::current()->getName() == 'settings' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Process Setup">
                        <a href="#"><i class="fa fa-rotate-right"></i> <span class="nav-label">Process Setup</span><span
                                class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="<?php echo e(url('/processes')); ?>"></i>Process</a></li>
                            <li><a href="<?php echo e(url('/policies')); ?>"></i>Policies</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Memorandum link -->
                    <?php if((auth()->user()->role == 'Administrator') || auth()->user()->role == 'Document Control Officer'): ?>
                        <li class="<?php echo e(Route::current()->getName() == 'memorandum' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Memorandum">
                            <a href="#"><i class="fa fa-sticky-note"></i> 
                                <span class="nav-label">Memorandum</span><span class="fa arrow"></span>
                            </a>
                            <ul class="nav nav-second-level collapse">
                                <li> 
                                    <a href="<?php echo e(url('memorandum')); ?>">
                                        <i class="fa fa-sticky-note"></i>
                                        For upload
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo e(url('for-approval-memorandum')); ?>">
                                    <i class="fa fa-check-square-o"></i>
                                    For Approval
                                    </a>
                                </li>
                                
                            </ul>
                        </li>
                    <?php else: ?>
                        <!--old structure before i add the dropdown menu  -->
                        <li class="<?php if(Request::is('memorandum')): ?> active <?php endif; ?>" data-toggle="tooltip" data-placement="right" title="Memorandum">
                            <a href="<?php echo e(url('memorandum')); ?>">
                                <i class="fa fa-sticky-note"></i>
                                <span class="nav-label">Memorandum </span>
                            </a>
                        </li>
                        <!-- End old memorandum link -->
                    <?php endif; ?>

                    <!-- Supporting document -->
                    <?php if((auth()->user()->role == 'Administrator') || auth()->user()->role == 'Document Control Officer'): ?>
                        <li class="<?php echo e(Route::current()->getName() == 'supporting_document' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Supporint Documents">
                            <a href="#"><i class="fa fa-file"></i>
                                <span class="nav-label">Supporting Files</span><span class="fa arrow"></span>
                            </a>
                            <ul class="nav nav-second-level collapse">
                                <li> 
                                    <a href="<?php echo e(url('supporting_document')); ?>">
                                        <i class="fa fa-sticky-note"></i>
                                        For upload
                                    </a>
                                </li>
                                <li>
                                    <a href="for-approval-supporting-documents">
                                    <i class="fa fa-check-square-o"></i>
                                    For Approval
                                    </a>
                                </li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="<?php if(Request::is('supporting_document')): ?> active <?php endif; ?>" data-toggle="tooltip" data-placement="right" title="Supporting Documents">
                            <a href="<?php echo e(url('supporting_document')); ?>">
                                <i class="fa fa-file"></i>
                                <span class="nav-label">Supporting Documents </span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <!--End supporting -->

                    <?php if((auth()->user()->role == 'Administrator') || auth()->user()->role == 'Business Process Manager'): ?>
                        <li class="<?php echo e(Route::current()->getName() == 'account_request' ? 'active' : ''); ?>" data-toggle="tooltip" data-placement="right" title="Account Request">
                            <a href="#"><i class="fa fa-file"></i>
                                <span class="nav-label">Account Request</span><span class="fa arrow"></span>
                            </a>
                            <ul class="nav nav-second-level collapse">
                                <li> 
                                    <a href="<?php echo e(url('account_request')); ?>">
                                        <i class="fa fa-sticky-note"></i>
                                        For Request
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('for-approval-accounts')); ?>">
                                    <i class="fa fa-check-square-o"></i>
                                        For Approval
                                    </a>
                                </li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="<?php if(Request::is('account_request')): ?> active <?php endif; ?>" data-toggle="tooltip" data-placement="right" title="Account Request">
                            <a href="<?php echo e(url('account_request')); ?>">
                                <i class="fa fa-file"></i>
                                <span class="nav-label">Account Request</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    
                </ul>
            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i
                                class="fa fa-bars"></i>
                             </a>
                            
                    </div>
                    <ul class="nav navbar-top-links navbar-right">
                        <li>
                            <span class="m-r-sm text-muted welcome-message" title='For Approval'>Welcome to <?php echo e(config('app.name', 'Laravel')); ?></span>
                        </li>
                        <li>
                            <a class=" count-info " href="<?php echo e(url('/for-approval')); ?>" title='For Approval'>
                                <i class="fa fa-bell"></i>  <span class="label label-warning"><?php echo e(copy_approver_count()); ?></span>
                            </a>
                        </li>
                        <?php if((auth()->user()->role == "Administrator") || (auth()->user()->role == "Document Control Officer") || (auth()->user()->id == "286")): ?>
                        <li>
                            <a class=" count-info " href="<?php echo e(url('/pre_assessment')); ?>" title='For Approval'>
                                <i class="fa fa-bell-o"></i>  <span class="label label-warning"><?php echo e(pre_assessment_count()); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>" onclick="logout(); show();">
                                <i class="fa fa-sign-out"></i> Log out
                            </a>
                        </li>
                    </ul>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </nav>
            </div>
            <?php echo $__env->yieldContent('content'); ?>
            <div class="footer">
                <div class='text-right'>
                    WGROUP DEVELOPER &copy; <?php echo e(date('Y')); ?>

                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="<?php echo e(asset('login_css/js/jquery-3.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('login_css/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('login_css/js/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>
    <script src="<?php echo e(asset('login_css/js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

    <script src="<?php echo e(asset('login_css/js/inspinia.js')); ?>"></script>
    <script src="<?php echo e(asset('login_css/js/plugins/pace/pace.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
    <script>
        function show() {
            document.getElementById("loader").style.display = "block";
        }

        function logout() {
            event.preventDefault();
            document.getElementById('logout-form').submit();
        }

    document.addEventListener('DOMContentLoaded', function() {
        const select = document.getElementById('reason-for-new-request');
        const options = select.querySelectorAll('option');
    
        options.forEach(option => {
            const text = option.textContent;
            const parts = text.split('(');
            if (parts.length > 1) {
                option.innerHTML = `<span class="bold-text">${parts[0]}</span>(${parts[1]}`;
            } else {
                option.innerHTML = `<span class="bold-text">${text}</span>`;
            }
        });
    });
    </script>

</body>
</html>
