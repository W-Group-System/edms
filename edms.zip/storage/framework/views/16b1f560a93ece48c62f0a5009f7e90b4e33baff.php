<div class="modal" id="newaccountrequest">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Request User Account</h5>
            </div>
            <form method="POST" action="<?php echo e(url('store_request_account')); ?>" enctype="multipart/form-data" onsubmit="show()">
                <?php echo csrf_field(); ?> 

                <div class="modal-body">
                    <div class="row">
                        <div class='col-md-12'>
                            Name :
                            <input type="text" class="form-control-sm form-control "  value="<?php echo e(old('name')); ?>"  name="name" required/>
                        </div>
                        <div class='col-md-12'>
                            Email :
                            <input type="email" class="form-control-sm form-control "  value="<?php echo e(old('email')); ?>"  name="email" required/>
                        </div>
                        <div class='col-md-12'>
                            Position :
                            <input type="text"  class="form-control-sm form-control" name="position" value="">
                        </div>
                        <div class="col-md-12">
                            Company :

                            <?php if((auth()->user()->role === 'Administrator') || (auth()->user()->department->code == "WGI-HRD")): ?>
                                <select name="company" class="form-control-sm form-control cat">
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($company->id); ?>"
                                            <?php echo e(auth()->user()->company_id == $company->id ? 'selected' : ''); ?>>
                                            <?php echo e($company->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php else: ?>
                                <input type="hidden" name="company" value="<?php echo e(auth()->user()->company_id); ?>">

                                <input type="text"
                                    class="form-control-sm form-control"
                                    value="<?php echo e(auth()->user()->company->name); ?>"
                                    readonly>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-12">
                            <?php if((auth()->user()->role === 'Administrator') || (auth()->user()->department->code == "WGI-HRD")): ?>
                                Department :
                                <select name="department" class="form-control-sm form-control cat">
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->id); ?>"
                                            <?php echo e(auth()->user()->department_id == $department->id ? 'selected' : ''); ?>>
                                            <?php echo e($department->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php else: ?>
                                Department :
                                <input type="hidden" name="department" value="<?php echo e(auth()->user()->department_id); ?>">

                                <input type="text" class="form-control-sm form-control" value="<?php echo e(auth()->user()->department->name); ?>" readonly>
                            <?php endif; ?>
                        </div>
                        <div class='col-md-12'>
                            Reason :
                            <textarea class="form-control-sm form-control" name="reason" rows="5"></textarea>
                        </div>
                       
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>