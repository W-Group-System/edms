<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('login_css/css/plugins/chosen/bootstrap-chosen.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('login_css/css/plugins/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper wrapper-content ">
   
    <div class="row ">
        <div class="col-lg-8 stretch-card">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Search Documents</h5>
                </div>
                <div class="ibox-content stretch-card">
                    <div class="search-form">
                        <form action="" method="get">
                            <div class='row'>
                                <div class='col-md-3'>
                                    Company :
                                    <select name='company' class='form-control-sm form-control cat' >
                                        <option value="">N/A</option>
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value='<?php echo e($company->id); ?>' <?php if($comp == $company->id): ?> selected <?php endif; ?>><?php echo e($company->name); ?> - <?php echo e($company->code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class='col-md-3'>
                                    Department :
                                    <select name='department' class='form-control-sm form-control cat' >
                                        <option value="">N/A</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value='<?php echo e($dep->id); ?>' <?php if($dept == $dep->id): ?> selected <?php endif; ?>><?php echo e($dep->code); ?> - <?php echo e($dep->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class='col-md-3'>
                                   &nbsp;
                                <input type="text" placeholder="Document TItle / Control Code / Old Code" name="search" value="<?php echo e($search); ?>"  class="form-control" >
                                </div>
                                <div class='col-md-3'>
                                    <button class="btn btn-lg btn-primary" type="submit">
                                        Filter
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="hr-line-dashed"></div>
                    <?php if($documents): ?>
                        <?php if($comp == 2 || $whiDept != null): ?>
                            <?php $__currentLoopData = $documents->where('category', 'PROCEDURE'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="search-result">
                                    <h3><a href="<?php echo e(url('view-document/'.$document->id)); ?>" target="_blank"><i>(<?php echo e($document->old_control_code); ?>)</i> <?php echo e($document->control_code); ?> Rev. <?php echo e($document->version); ?></a> <?php if($document->public == null): ?><span class="label label-danger">Private</span><?php else: ?><span class="label label-primary">Public</span><?php endif; ?></h3>
                                    Title : <?php echo e($document->title); ?><br>
                                    Process Owner : 
                                    
                                    <?php if($document->process_owner != null): ?>
                                        <small class="label label-info"><?php echo e($document->processOwner->name); ?></small>
                                    <?php else: ?> 
                                        <small class="label label-info"><?php echo e($document->department->dep_head->name); ?></small>
                                    <?php endif; ?>
                                    <p>
                                        Date Effective : <?php echo e(date('M d, Y',strtotime($document->updated_at))); ?> <br>
                                        Company : <?php echo e($document->department->name); ?>

                                        
                                    </p>
                                </div>
                                <div class="hr-line-dashed"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                        
                        <?php $__currentLoopData = $documents->where('category', 'POLICY'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="search-result">
                                <h3><a href="<?php echo e(url('view-document/'.$document->id)); ?>" target="_blank"><i>(<?php echo e($document->old_control_code); ?>)</i> <?php echo e($document->control_code); ?> Rev. <?php echo e($document->version); ?></a> <?php if($document->public == null): ?><span class="label label-danger">Private</span><?php else: ?><span class="label label-primary">Public</span><?php endif; ?></h3>
                                Title : <?php echo e($document->title); ?><br>
                                
                                Process Owner : 
                                <?php if($document->process_owner != null): ?>
                                    <small class="label label-info"><?php echo e($document->processOwner->name); ?></small>
                                <?php else: ?> 
                                    <small class="label label-info"><?php echo e($document->department->dep_head->name); ?></small>
                                <?php endif; ?>
                                <p>
                                    Date Effective : <?php echo e(date('M d, Y',strtotime($document->updated_at))); ?> <br>
                                    Company : <?php echo e($document->department->name); ?>

                                    
                                </p>
                            </div>
                            <div class="hr-line-dashed"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php $__currentLoopData = $documents->where('category', 'FORM'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="search-result">
                                <h3><a href="<?php echo e(url('view-document/'.$document->id)); ?>" target="_blank"><i>(<?php echo e($document->old_control_code); ?>)</i> <?php echo e($document->control_code); ?> Rev. <?php echo e($document->version); ?></a> <?php if($document->public == null): ?><span class="label label-danger">Private</span><?php else: ?><span class="label label-primary">Public</span><?php endif; ?></h3>
                                Title : <?php echo e($document->title); ?><br>
                                
                                Process Owner : 
                                <?php if($document->process_owner != null): ?>
                                    <small class="label label-info"><?php echo e($document->processOwner->name); ?></small>
                                <?php else: ?> 
                                    <small class="label label-info"><?php echo e($document->department->dep_head->name); ?></small>
                                <?php endif; ?>
                                <p>
                                    Date Effective : <?php echo e(date('M d, Y',strtotime($document->updated_at))); ?> <br>
                                    Company : <?php echo e($document->department->name); ?>

                                    
                                </p>
                            </div>
                            <div class="hr-line-dashed"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php $__currentLoopData = $documents->where('category', 'TEMPLATE'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="search-result">
                                <h3><a href="<?php echo e(url('view-document/'.$document->id)); ?>" target="_blank"><i>(<?php echo e($document->old_control_code); ?>)</i> <?php echo e($document->control_code); ?> Rev. <?php echo e($document->version); ?></a> <?php if($document->public == null): ?><span class="label label-danger">Private</span><?php else: ?><span class="label label-primary">Public</span><?php endif; ?></h3>
                                Title : <?php echo e($document->title); ?><br>
                                
                                Process Owner : 
                                <?php if($document->process_owner != null): ?>
                                    <small class="label label-info"><?php echo e($document->processOwner->name); ?></small>
                                <?php else: ?> 
                                    <small class="label label-info"><?php echo e($document->department->dep_head->name); ?></small>
                                <?php endif; ?>
                                <p>
                                    Date Effective : <?php echo e(date('M d, Y',strtotime($document->updated_at))); ?> <br>
                                    Company : <?php echo e($document->department->name); ?>

                                    
                                </p>
                            </div>
                            <div class="hr-line-dashed"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php $__currentLoopData = $documents->where('category', 'ANNEX'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="search-result">
                                <h3><a href="<?php echo e(url('view-document/'.$document->id)); ?>" target="_blank"><i>(<?php echo e($document->old_control_code); ?>)</i> <?php echo e($document->control_code); ?> Rev. <?php echo e($document->version); ?></a> <?php if($document->public == null): ?><span class="label label-danger">Private</span><?php else: ?><span class="label label-primary">Public</span><?php endif; ?></h3>
                                Title : <?php echo e($document->title); ?><br>
                                
                                Process Owner : 
                                <?php if($document->process_owner != null): ?>
                                    <small class="label label-info"><?php echo e($document->processOwner->name); ?></small>
                                <?php else: ?> 
                                    <small class="label label-info"><?php echo e($document->department->dep_head->name); ?></small>
                                <?php endif; ?>
                                <p>
                                    Date Effective : <?php echo e(date('M d, Y',strtotime($document->updated_at))); ?> <br>
                                    Company : <?php echo e($document->department->name); ?>

                                    
                                </p>
                            </div>
                            <div class="hr-line-dashed"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php
                            $category = array('POLICY', 'FORM', 'TEMPLATE', 'ANNEX', 'PROCEDURE');
                        ?>
                        <?php $__currentLoopData = $documents->whereNotIn('category', $category); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="search-result">
                                <h3><a href="<?php echo e(url('view-document/'.$document->id)); ?>" target="_blank"><i>(<?php echo e($document->old_control_code); ?>)</i> <?php echo e($document->control_code); ?> Rev. <?php echo e($document->version); ?></a> <?php if($document->public == null): ?><span class="label label-danger">Private</span><?php else: ?><span class="label label-primary">Public</span><?php endif; ?></h3>
                                Title : <?php echo e($document->title); ?><br>
                                
                                Process Owner : 
                                <?php if($document->process_owner != null): ?>
                                    <small class="label label-info"><?php echo e($document->processOwner->name); ?></small>
                                <?php else: ?> 
                                    <small class="label label-info"><?php echo e($document->department->dep_head->name); ?></small>
                                <?php endif; ?>
                                <p>
                                    Date Effective : <?php echo e(date('M d, Y',strtotime($document->updated_at))); ?> <br>
                                    Company : <?php echo e($document->department->name); ?>

                                    
                                </p>
                            </div>
                            <div class="hr-line-dashed"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Public Documents </h5>
                </div>
                <div class="ibox-content">
                    <table class="table table-striped table-bordered table-hover tables">
                        <thead>
                            <tr>
                                <th>Document</th>
                                <th>Department</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $request_documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req_doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php
                                        $attchment = ($req_doc->attachments)->where('type','pdf_copy')->first();
                                    ?>
                                    <td>
                                        <?php if($attchment): ?>
                                        <a href="<?php echo e(url($attchment->attachment)); ?>" target="_blank"><i class="fa fa-file"></i> <?php echo e($req_doc->title); ?></a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($req_doc->department->code); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('login_css/js/plugins/dataTables/datatables.min.js')); ?>"></script>

<script src="<?php echo e(asset('login_css/js/plugins/chosen/chosen.jquery.js')); ?>"></script>
<script>
   
    $(document).ready(function(){
        
        $('.cat').chosen({width: "100%"});
        $('.tables').DataTable({
            pageLength: 10,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                
            ]

        });

    });

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>