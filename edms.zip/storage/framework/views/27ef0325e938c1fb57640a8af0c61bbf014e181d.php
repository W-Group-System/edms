<div class="modal" id="view_request<?php echo e($request->id); ?>" tabindex="-1" role="dialog"  >
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class='col-md-10'>
                    <h5 class="modal-title" id="exampleModalLabel">Change Request 
                        <?php if(optional($request->preAssessment)->status == "Pending"): ?> 
                            (Pre-Assessment) 
                        <?php else: ?> 
                            (<?php echo e($request->status); ?>)
                        <?php endif; ?>
                    </h5>
                </div>
                <div class='col-md-2'>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            
                <div class="modal-body">
                    <div class='row '>
                        <div class='col-md-6'>
                            Reference Number : <?php if(optional($request->preAssessment)->status != "Pending"): ?><b>DICR-<?php echo e(str_pad($request->id, 5, '0', STR_PAD_LEFT)); ?></b><?php endif; ?>
                        </div>
                        <div class='col-md-6'>
                            Type of Document : <?php echo e($request->type_of_document); ?>

                        </div>
                        <div class='col-md-6'>
                            
                            Classification : <?php echo e($request->classification); ?>

                        </div>
                       
                        <div class='col-md-6'>
                            <?php if($request->request_type != "Obsolete"): ?>
                            Draft Link : <a href='<?php echo e($request->link_draft); ?>' target="_blank">Draft Link</a> <br>
                           
                            <?php endif; ?>
                           <?php if($request->original_attachment_pdf != null): ?>
                           Original PDF Link : <a href='<?php echo e(url($request->original_attachment_pdf."?page=hsn#toolbar=0")); ?>' target="_blank">Link</a> <br>
                           <?php endif; ?>
                           
                            <?php if($request->supporting_documents != null): ?>
                            Supporting Documents : <a href="<?php echo e(url($request->supporting_documents)); ?>" target="_blank">Link</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <hr>
                    <div class='row '>
                        <?php if($request->request_type != "New"): ?>
                        <div class='col-md-6'>
                            Control Code : <?php echo e($request->control_code); ?> Rev. <?php echo e($request->revision); ?>

                        </div>
                        <?php endif; ?>
                        <div class='col-md-6'>
                            Title : <?php echo e($request->title); ?>

                        </div>
                    </div>
                    <div class='row '>
                        <div class='col-md-6'>
                            Requested By : <?php echo e($request->user->name); ?> 
                        </div>
                        <div class='col-md-6'>
                            Date Requested : <?php echo e(date('M d, Y',strtotime($request->created_at))); ?>

                        </div>
                    </div>
                    <hr>
                    <div class='row '>
                        <div class='col-md-12'>
                            Request Type: <b><?php echo e($request->request_type); ?></b>
                        </div>
                    </div>
                    <?php if($request->request_type != 'Obsolete'): ?>
                    <div class="row">
                        <div class="col-md-12">
                            Reason for changes : <b><?php echo e($request->reason_for_changes); ?></b>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class='row'>
                        <div class='col-md-12 '>
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <?php if($request->request_type != "Revision"): ?>
                                        Descriptions/Remarks
                                    <?php else: ?>
                                    Reason/s for Change
                                    <?php endif; ?>
                                </div>
                                <div class="panel-body">
                                    <?php echo nl2br(e($request->change_request)); ?>

                                </div>
                            </div>
                            
                            
                        </div>
                    </div>
                 
                    <?php if($request->request_type == "Revision"): ?>
                    <div class='row '>
                        <div class='col-md-6 '>
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    From (Indicate clause)
                                </div>
                                <div class="panel-body">
                                    <?php echo nl2br(e($request->indicate_clause)); ?>

                                </div>
                            </div>
                        </div>
                        <div class='col-md-6'>
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    To (Indicate the changes)
                                </div>
                                <div class="panel-body">
                                    <?php echo nl2br(e($request->indicate_changes)); ?>

                                </div>
                            </div>
                           
                            
                        </div>
                    </div>
                    <?php endif; ?>
                    <hr>
                    Action : <?php if(optional($request->preAssessment)->status == "Pending"): ?> <b>Pre-Assessment</b> <?php else: ?> <b>Change Request</b> <?php endif; ?>
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Approvers
                        </div>
                        <div class="panel-body">
                            <div class='row'>
                                <div class='col-md-3  border border-primary border-top-bottom border-left-right'>
                                    Name
                                </div>
                                <div class='col-md-3  border border-primary border-top-bottom border-left-right'>
                                    Status
                                </div>
                                <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                    Start Date
                                </div>
                                <div class='col-md-2  border border-primary border-top-bottom border-left-right'>
                                   Action Date
                                </div>
                                <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                    Remarks
                                </div>
                            </div>
                            <?php if(optional($request->preAssessment)->status == "Pending"): ?>
                                <div class='row'>
                                    <div class='col-md-3 border border-primary border-top-bottom border-left-right'>
                                        <?php echo e(optional(optional($request->preAssessment->approvers)->user)->name); ?>

                                    </div>
                                    <div class='col-md-3 border border-primary border-top-bottom border-left-right'>
                                        <?php echo e(optional($request->preAssessment->approvers)->status); ?>

                                    </div>
                                    <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                        
                                        <?php if(optional($request->preAssessment->approvers)->start_date != null): ?> <?php echo e(optional($request->preAssessment->approvers)->start_date); ?> <?php endif; ?> &nbsp;
                                    </div>
                                    <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                        
                                        &nbsp;
                                    </div>
                                    <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                        
                                        &nbsp;
                                    </div>
                                </div>
                            <?php else: ?> 
                                <?php $__currentLoopData = $request->approvers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            
                                            <div class='row'>
                                                <div class='col-md-3 border border-primary border-top-bottom border-left-right'>
                                                    <?php echo e($approver->user->name); ?>

                                                </div>
                                                <div class='col-md-3 border border-primary border-top-bottom border-left-right'>
                                                    <?php echo e($approver->status); ?>

                                                </div>
                                                <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                                    <?php if($approver->start_date != null): ?><?php echo e($approver->start_date); ?><?php endif; ?> &nbsp;
                                                </div>
                                                <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                                    
                                                    <?php if($approver->status != "Waiting" && $approver->status != "Pending"): ?>
                                                        <?php echo e(date('Y-m-d',strtotime($approver->updated_at))); ?>

                                                    <?php endif; ?>
                                                </div>
                                                <div class='col-md-2 border border-primary border-top-bottom border-left-right'>
                                                    <?php echo nl2br(e($approver->remarks)); ?>&nbsp;
                                                </div>
                                            </div>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
        </div>
    </div>
</div>
