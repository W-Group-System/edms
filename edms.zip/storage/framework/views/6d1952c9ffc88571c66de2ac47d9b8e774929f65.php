<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade policies-modal-new" id="policiesModal<?php echo e($department->id); ?>" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <div class="col-md-10">
                    <h5 class="modal-title">
                        <?php echo e($department->name); ?> Policies - Total: <?php echo e($department->total_policies + $department->total_annexes); ?>

                    </h5>
                </div>
                 <div class="col-md-2">
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                 </div>
            </div>

            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover tables" >
                        <thead>
                            <tr>
                                <th>Process</th>
                                <th>Policy - <?php echo e($department->total_policies); ?></th>
                                <th>Annex - <?php echo e($department->total_annexes); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $processNo = 1; ?>
                            <?php $__currentLoopData = $department->process_rel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php
                                    $policies = $process->policies;

                                    $processRowCount = $policies->sum(function ($policy) {
                                        return max($policy->annexes->count(), 1);
                                    });

                                    $processRendered = false;
                                ?>

                                <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php
                                        $subPolicies = $policy->annexes;
                                        $subPolicyCount = max($subPolicies->count(), 1);
                                        $policyRendered = false;
                                    ?>

                                    <?php if($subPolicies->isNotEmpty()): ?>
                                        <?php $__currentLoopData = $subPolicies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subPolicy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php if(!$processRendered): ?>
                                                    <td rowspan="<?php echo e($processRowCount); ?>">
                                                        <?php echo e($processNo); ?>. <?php echo e($process->process_name); ?>

                                                    </td>
                                                    <?php $processRendered = true; ?>
                                                    <?php $processNo++; ?>
                                                <?php endif; ?>

                                                <?php if(!$policyRendered): ?>
                                                    <td rowspan="<?php echo e($subPolicyCount); ?>">
                                                        <a href="<?php echo e(url('view-document/'.$policy->document->id)); ?>"
                                                            target="_blank">
                                                            <?php echo e($policy->document->control_code); ?> -
                                                            <?php echo e($policy->document->title); ?>

                                                        </a>

                                                    </td>
                                                    <?php $policyRendered = true; ?>
                                                <?php endif; ?>

                                                <td>
                                                    <a href="<?php echo e(url('view-document/'.$subPolicy->document->id)); ?>"
                                                        target="_blank">
                                                        <?php echo e($subPolicy->document->control_code ?? ''); ?> - <?php echo e($subPolicy->document->title ?? ''); ?>

                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php else: ?>
                                        <tr>
                                            <?php if(!$processRendered): ?>
                                                <td rowspan="<?php echo e($processRowCount); ?>">
                                                    <?php echo e($processNo); ?>. <?php echo e($process->process_name); ?>

                                                </td>
                                                <?php $processNo++; ?>
                                            <?php endif; ?>

                                            <td>
                                                <a href="<?php echo e(url('view-document/'.$policy->document->id)); ?>"
                                                    target="_blank">
                                                    <?php echo e($policy->document->control_code); ?> -
                                                    <?php echo e($policy->document->title); ?>

                                                </a>

                                            </td>

                                            <td>—</td>

                                            <?php if(!$processRendered): ?>
                                                <?php $processRendered = true; ?>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
