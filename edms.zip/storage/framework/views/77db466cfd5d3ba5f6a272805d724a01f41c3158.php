
<div class="modal" id="changeType<?php echo e($permit->id); ?>" tabindex="-1" role="dialog"  >
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class='col-md-10'>
                    <h5 class="modal-title" >Change Type</h5>
                </div>
                <div class='col-md-2'>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            
        
        <form method='post' action='change-type/<?php echo e($permit->id); ?>' onsubmit='show();'  enctype="multipart/form-data" >
                <div class="modal-body">
                    <?php echo e(csrf_field()); ?>

                    <div class='row'>
                        <div class='col-md-12'>
                            Title :
                            <input name='title' value='<?php echo e($permit->title); ?>' class='form-control form-control-sm' required>
                        </div>
                    </div>
                    <div class='row'>
                        <div class='col-md-12'>
                            Type :
                            <input name='type' value='<?php echo e($permit->type); ?>' class='form-control form-control-sm' required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type='submit'  class="btn btn-primary" >Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>